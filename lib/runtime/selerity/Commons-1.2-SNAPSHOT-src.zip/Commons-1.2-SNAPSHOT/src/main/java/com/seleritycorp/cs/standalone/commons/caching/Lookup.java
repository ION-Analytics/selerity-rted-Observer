package com.seleritycorp.cs.standalone.commons.caching;

/**
 * An interface denoting the ability to find a value by key.
 */
public interface Lookup<K, V> {
    /**
     * Get a value by key.
     * @param key the key to search by.
     * @return the value found, or null if not found
     */
    V get(K key);
}

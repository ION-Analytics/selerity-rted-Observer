/*
 * (c) Copyrights Selerity, Inc. 2009-2011. All rights reserved. This source code is confidential
 * and proprietary information of Selerity Inc. and may be used only by a recipient designated
 * by and for the purposes permitted by Selerity Inc. in writing.  Reproduction of, dissemination
 * of, modifications to or creation of derivative works from this source code, whether in source
 * or binary forms, by any means and in any form or manner, is expressly prohibited, except with
 * the prior written permission of Selerity Inc..  THIS CODE AND INFORMATION ARE PROVIDED “AS IS”
 * WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. This notice may not be
 * removed from the software by any user thereof.
 */

package com.seleritycorp.cs.standalone.commons;

import java.util.concurrent.TimeUnit;

/**
 * Classes implementing this interface provide a Runnable and information needed to repeatedly run it.
 */
public interface ScheduledRunnable {
    /**
     * How long to wait for the first run.
     * @return number of units
     */
    long getInitialDelay();

    /**
     * Period between subsequent runs.
     * @return number of units
     */
    long getPeriod();

    /**
     * Units the initial delay and period are measured in.
     * @return units
     */
    TimeUnit getUnit();

    /**
     * The runnable to run.
     * @return runnable.
     */
    Runnable getRunnable();
}

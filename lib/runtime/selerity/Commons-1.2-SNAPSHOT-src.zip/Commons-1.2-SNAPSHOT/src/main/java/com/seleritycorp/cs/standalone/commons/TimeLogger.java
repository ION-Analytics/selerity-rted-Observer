/*
 * (c) Copyrights Selerity, Inc. 2009-2011. All rights reserved. This source code is confidential
 * and proprietary information of Selerity Inc. and may be used only by a recipient designated
 * by and for the purposes permitted by Selerity Inc. in writing.  Reproduction of, dissemination
 * of, modifications to or creation of derivative works from this source code, whether in source
 * or binary forms, by any means and in any form or manner, is expressly prohibited, except with
 * the prior written permission of Selerity Inc..  THIS CODE AND INFORMATION ARE PROVIDED “AS IS”
 * WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. This notice may not be
 * removed from the software by any user thereof.
 */

package com.seleritycorp.cs.standalone.commons;

import java.util.ArrayList;
import java.util.List;

/** 
 * Logs events and the times that they occur.
 * 
 * Note, this class is *not* threadsafe.  Method access must be synchronized if this object may be accessed concurrently.
 */
public class TimeLogger {
    public static final int DEFAULT_SIZE = 10;
	protected final List<LogEntry> entries;
    protected String name;
		
	public TimeLogger() {
		this(null, DEFAULT_SIZE);
	}
	
	public TimeLogger(String name) {
		this(name, DEFAULT_SIZE);
	}
	
	public TimeLogger(String name, int initialSize) {
		this.name = (name == null ? getClass().getSimpleName() : name);
		this.entries = new ArrayList<LogEntry>(initialSize);
	}
	
	public String getName() {
		return this.name;
	}

    public void setName(final String name) {
        this.name = name;
    }

    public void addEntry(String description) {
		entries.add(new LogEntry(description, new Timestamp()));
	}
	
	public void addEntry(String description, Timestamp timestamp) {
		entries.add(new LogEntry(description, timestamp));
	}
	
	/**
     * Returns the log as a string formatted for easy timestamp comparison.
     */
	public String toString() {
        final StringBuilder s = new StringBuilder();
                
		s.append("Log for " + name + ":\n");
        if (entries.size() > 0) {
            LogEntry last = entries.get(0);
            for (LogEntry entry : entries) {
                s.append("  ");
                s.append(entry.timestamp);
                s.append(" : ");
                s.append(String.format("%15d", entry.timestamp.getTimeInNanos() - last.timestamp.getTimeInNanos()));
                s.append(" : ");
                s.append(entry.description);
                s.append("\n");
                last = entry;
            }
        }
		return s.toString();
	}

    protected final class LogEntry {
        public final String description;
        public final Timestamp timestamp;

        public LogEntry(String description, Timestamp timestamp) {
            this.description = description;
            this.timestamp = timestamp;
        }
    }
}

/*
 * (c) Copyright Selerity, Inc. 2009-2012. All rights reserved. This source code is confidential
 * and proprietary information of Selerity Inc. and may be used only by a recipient designated
 * by and for the purposes permitted by Selerity Inc. in writing.  Reproduction of, dissemination
 * of, modifications to or creation of derivative works from this source code, whether in source
 * or binary forms, by any means and in any form or manner, is expressly prohibited, except with
 * the prior written permission of Selerity Inc..  THIS CODE AND INFORMATION ARE PROVIDED "AS IS"
 * WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. This notice may not be
 * removed from the software by any user thereof.
 */

package com.seleritycorp.cs.standalone.commons.caching;

import org.springframework.jmx.export.annotation.ManagedAttribute;

import java.util.concurrent.TimeUnit;

/**
 *  Management bean.
 */
public abstract class AbstractCacheMBean<M extends AbstractCacheMBean.ManageableCache> extends AbstractMapMBean<M> {
    /**
     * Gets the number of max elements in memory
     * @return the number of max elements in memory
     */
    @ManagedAttribute(description = "Gets number of max elements in memory.")
    public int getMaximumSize() {
        return getMap().getMaximumSize();
    }

    /**
     * Sets the number of max elements in memory
     * @param maxElementsInMemory max elements in memory
     */
    @ManagedAttribute(description = "Sets number of max elements in memory.")
    public void setMaximumSize(int maxElementsInMemory) {
        getMap().setMaximumSize(maxElementsInMemory);
    }

    /**
     * Gets number of cache hits.
     * @return the number of hits
     */
    @ManagedAttribute(description = "Gets number of cache hits.")
    public long getHits() {
        return getMap().getCacheHitCount();
    }

    /**
     * Get the number of cache misses.
     * @return the number of misses
     */
    @ManagedAttribute(description = "Gets number of cache misses.")
    public long getMisses() {
        return getMap().getCacheMissCount();
    }

    /**
     * Get the percentage of cache hits.
     * @return percentage of cache hits
     */
    @ManagedAttribute(description = "Gets percentage of cache hits.")
    public double getPercentHits() {
        double hits = getHits();
        double misses = getMisses();
        return 100.0 * hits / (hits + misses);
    }

    @ManagedAttribute(description = "Get the element time to live, 0 means infinite")
    public long getTimeToLive() {
        return getMap().getTimeToLive();
    }

    @ManagedAttribute(description = "Set the element time to live, 0 means infinite.")
    public void setTimeToLive(long timeToLive) {
        getMap().setTimeToLive(timeToLive);
    }

    @ManagedAttribute(description = "Unit the time to live is measured in.")
    public String getTimeToLiveUnits() {
        return getMap().getTimeToLiveUnits().name();
    }

    @ManagedAttribute(description = "Set the unit the ttl is measured in: SECONDS, MINUTES, HOURS.")
    public void setTimeToLiveUnits(String timeToLiveUnits) {
        getMap().setTimeToLiveUnits(TimeUnit.valueOf(timeToLiveUnits));
    }

    public static interface ManageableCache extends ManageableMap {
        int getMaximumSize();
        void setMaximumSize(int size);
        int getCacheHitCount();
        int getCacheMissCount();
        long getTimeToLive();
        void setTimeToLive(long timeToLive);
        TimeUnit getTimeToLiveUnits();
        void setTimeToLiveUnits(TimeUnit timeToLiveUnits);
    }
}

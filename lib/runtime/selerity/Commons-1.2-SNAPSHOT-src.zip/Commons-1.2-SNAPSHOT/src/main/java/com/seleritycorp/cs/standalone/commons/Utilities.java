/*
 * © Copyrights Selerity, Inc. 2009-2011. All rights reserved. This source code is confidential
 * and proprietary information of Selerity Inc. and may be used only by a recipient designated
 * by and for the purposes permitted by Selerity Inc. in writing.  Reproduction of, dissemination
 * of, modifications to or creation of derivative works from this source code, whether in source
 * or binary forms, by any means and in any form or manner, is expressly prohibited, except with
 * the prior written permission of Selerity Inc..  THIS CODE AND INFORMATION ARE PROVIDED "AS IS"
 * WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. This notice may not be
 * removed from the software by any user thereof.
 */

package com.seleritycorp.cs.standalone.commons;


import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.UUID;

public class Utilities {

    /**
     * Writes a banner to the console.
     *
     * @param caller class calling this method
     * @param title  banner title to print to the console
     */
    public static void consoleBanner(final Object caller, final String title) {
        consoleBanner(caller.getClass().getSimpleName() + " : " + title);
    }

    /**
     * Writes a banner to the console.
     *
     * @param title banner title to print to the console
     */
    public static void consoleBanner(final String title) {
        System.out.println();
        System.out.println();
        System.out.println();
        System.out.println();
        System.out.println("===================================================================================================================");
        System.out.println(space(title));
        System.out.println("===================================================================================================================");
    }

    private static String space(String s) {
        String result = "";
        for (char c : s.toCharArray()) {
            result += c + " ";
        }
        return result.toUpperCase();
    }

    /**
     * Gets the stack trace for an exception as a string.
     *
     * @param t exception
     * @return dump of the stack trace of the exception
     */
    public static String getStackTrace(Throwable t) {
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        t.printStackTrace(pw);
        return sw.getBuffer().toString();
    }

    /**
     * Gets string representation of an object, if object is null, result is null value.
     *
     * @param o object to convert
     * @return string representation of the object
     */
    public static String toString(Object o) {
        if (o == null) {
            return null;
        }
        return o.toString();
    }

    /**
     * Converts an object to UUID, if string is null or empty, returns null.
     *
     * @param o Object to convert
     * @return UUID from this object.
     */
    public static UUID toUUID(Object o) {
        try {
            if (o == null) {
                return null;
            } else if (o instanceof UUID) {
                return (UUID) o;
            } else {
                final String str = o.toString().trim();
                if (str == null || str.length() < 1) {
                    return null;
                }
                return UUID.fromString(str);
            }
        } catch (Exception e) {
            throw new IllegalArgumentException("Problem converting '" + o + "' to UUID", e);
        }
    }

    /**
     * Outputs a collection of object as a string. If the value of the argument is <code>null</code> then the result is a <code>null</code> string.
     *
     * @param objects objects to be converted to string form
     * @return string of the object, <code>null</code> iff the object given is <code>null</code>
     */
    public static Collection<String> collectionToString(final Collection<?> objects) {
        if (objects == null) {
            return null;
        } else if (objects.isEmpty()) {
            return Collections.emptyList();
        } else {
            Collection<String> output = new ArrayList<>(objects.size());
            for (Object o : objects) {
                output.add(toString(o));
            }
            return output;
        }
    }
}

/*
 * © Copyrights Selerity, Inc. 2009-2011.
 * All rights reserved. This source code is confidential and proprietary information of Selerity Inc.
 * and may be used only by a recipient designated by and for the purposes permitted by Selerity Inc. in writing.
 * Reproduction of, dissemination of, modifications to or creation of derivative works from this source code,
 * whether in source or binary forms, by any means and in any form or manner, is expressly prohibited,
 * except with the prior written permission of Selerity Inc..
 * THIS CODE AND INFORMATION ARE PROVIDED “AS IS” WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
 * This notice may not be removed from the software by any user thereof.
 */

package com.seleritycorp.cs.standalone.commons.logging;

import java.util.logging.Logger;

/**
 * Base class for classes that support logging.
 */
public class DoesLoggingImpl implements DoesLogging {
    private static final NullLogger NULL_LOGGER = new NullLogger();
    private transient Logger logger;

    public DoesLoggingImpl() {
        logger = Logger.getLogger(getClass().getName());
    }

    @Override
    public Logger getLogger() {
        return logger;
    }

    @Override
    public void setLogger(Logger logger) {
        if (logger == null) {
            this.logger = NULL_LOGGER;
        } else {
            this.logger = logger;
            this.logger.finer("Logger set to instance of " + logger.getClass().getCanonicalName());
        }
    }

}

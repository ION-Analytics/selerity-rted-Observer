/*
 * (c) Copyrights Selerity, Inc. 2009-2011. All rights reserved. This source code is confidential
 * and proprietary information of Selerity Inc. and may be used only by a recipient designated
 * by and for the purposes permitted by Selerity Inc. in writing.  Reproduction of, dissemination
 * of, modifications to or creation of derivative works from this source code, whether in source
 * or binary forms, by any means and in any form or manner, is expressly prohibited, except with
 * the prior written permission of Selerity Inc..  THIS CODE AND INFORMATION ARE PROVIDED “AS IS”
 * WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. This notice may not be
 * removed from the software by any user thereof.
 */

package com.seleritycorp.cs.standalone.commons;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

/**
 * Date utilities.
 */
public class DateUtils {
    private static final TimeZone UTC_TIMEZONE = TimeZone.getTimeZone("UTC");
    private static final String ISO_8601_PARSE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS";
    public static final String ISO_8601_FORMAT = ISO_8601_PARSE_FORMAT + "'000000'";

    /**
     * Java date to the ISO 8601 string format in UTF timezone.
     *
     * @param date the date to format
     * @return the formated string
     */
    public static String format(Date date) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(ISO_8601_FORMAT);
        simpleDateFormat.setTimeZone(UTC_TIMEZONE);
        return simpleDateFormat.format(date);
    }

    /**
     * Parse and ISO 8601 format string to a UNIX date.
     *
     * @param dateStr@return the Date
     * @return resultant date
     * @throws java.text.ParseException if it can not be passed
     */
    public static Date parse(String dateStr) throws ParseException {
        if (dateStr == null) {
            return null;
        }
        DateFormat simpleDateFormat = new SimpleDateFormat(ISO_8601_PARSE_FORMAT);
        simpleDateFormat.setTimeZone(UTC_TIMEZONE);
        return simpleDateFormat.parse(dateStr.substring(0, 23));
    }
}

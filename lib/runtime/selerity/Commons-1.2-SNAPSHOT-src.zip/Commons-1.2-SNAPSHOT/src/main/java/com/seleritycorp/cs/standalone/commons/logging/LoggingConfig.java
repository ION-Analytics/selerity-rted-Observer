package com.seleritycorp.cs.standalone.commons.logging;

import java.io.IOException;
import java.io.InputStream;
import java.util.logging.LogManager;

import static com.seleritycorp.cs.standalone.commons.IOUtilities.getResourceAsStream;

/**
 * A Java Logging config that uses the standard system property java.util.logging.config.file as
 * a resource name to search application jars for.  So for example:
 *
 *  java -Djava.util.logging.config.file=log.properties \
 *  -Djava.util.logging.config.class=com.seleritycorp.cs.standalone.commons.logging.LoggingConfig \
 *  -jar foo.jar
 *
 *  Will search for log.properties in foo.jar and use those to configure Java logging.
 */
public class LoggingConfig {
    public LoggingConfig() {
        final String resource = System.getProperty("java.util.logging.config.file", "logging.properties");
        final InputStream inputStream = getResourceAsStream(resource);
        try {
            LogManager.getLogManager().readConfiguration(inputStream);
        } catch (IOException e) {
            System.err.println("Could not load logging config from resource " + resource);
        }
    }
}

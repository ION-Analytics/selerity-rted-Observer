/*
 * © Copyrights Selerity, Inc. 2009-2011.
 * All rights reserved. This source code is confidential and proprietary information of Selerity Inc.
 * and may be used only by a recipient designated by and for the purposes permitted by Selerity Inc. in writing.
 * Reproduction of, dissemination of, modifications to or creation of derivative works from this source code,
 * whether in source or binary forms, by any means and in any form or manner, is expressly prohibited,
 * except with the prior written permission of Selerity Inc..
 * THIS CODE AND INFORMATION ARE PROVIDED “AS IS” WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
 * This notice may not be removed from the software by any user thereof.
 */

package com.seleritycorp.cs.standalone.commons;

/**
 * An abstract to normalise type conversions.
 * @param <L> the left type
 * @param <R> the right type
 */
public abstract class Mapper<L, R> {

    /**
     * Map a right type to a left.
     *
     * @param right the right type
     * @param left the left type
     * @throws ClassCastException if the request can not be executed
     */
    public abstract void toLeft(R right, L left) throws ClassCastException;

    /**
     * Map a left to a right.
     *
     * @param left the left type
     * @param right the right type
     * @throws ClassCastException if the request can not be executed
     */
    public abstract void toRight(L left, R right) throws ClassCastException;

    /**
     * Creates a new empty left.
     * @return new left object.
     */
    public abstract L newLeft();

    /**
     * Create a right object.

     * @return new right object
     */
    public abstract R newRight();

    /**
     * Map a right to a left.
     *
     * @param right the right type
     * @return left
     * @throws ClassCastException if the request can not be executed
     */
    public L toLeft(R right) throws ClassCastException {
        if (right == null) {
            return null;
        }
        final L left = newLeft();
        toLeft(right, left);
        return left;
    }

    /**
     * Map a left to a right.
     *
     * @param left the left type
     * @return right
     * @throws ClassCastException if the request can not be executed
     */
    public R toRight(L left) throws ClassCastException {
        if (left == null) {
            return null;
        }
        final R right = newRight();
        toRight(left, right);
        return right;
    }
}

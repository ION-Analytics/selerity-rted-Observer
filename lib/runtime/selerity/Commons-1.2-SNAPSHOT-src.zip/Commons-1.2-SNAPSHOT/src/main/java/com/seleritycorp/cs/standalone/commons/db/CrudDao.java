/*
 * (c) Copyright Selerity, Inc. 2009-2012. All rights reserved. This source code is confidential
 * and proprietary information of Selerity Inc. and may be used only by a recipient designated
 * by and for the purposes permitted by Selerity Inc. in writing.  Reproduction of, dissemination
 * of, modifications to or creation of derivative works from this source code, whether in source
 * or binary forms, by any means and in any form or manner, is expressly prohibited, except with
 * the prior written permission of Selerity Inc..  THIS CODE AND INFORMATION ARE PROVIDED "AS IS"
 * WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. This notice may not be
 * removed from the software by any user thereof.
 */

package com.seleritycorp.cs.standalone.commons.db;

/**
 * Basic interface for doing Create, Read, Update, Delete operations.
 * @param <T> Generic class to do Crud on.
 */
public interface CrudDao<K,T extends Entity<K>> {

    
    /**
     * Create an object.
     * @param object object to create.
     * @return Object created.
     * @throws DatabaseException if things went wrong.
     */
    T create(final T object) throws DatabaseException;
    
    /**
     * Finds an object by its ID.
     * @param id object's id.
     * @return Object if found, null otherwise.
     * @throws DatabaseException if things went wrong.
     */
    T findById(final K id) throws DatabaseException;
    
    /**
     * Updates an object.
     * @param object object to update
     * @throws DatabaseException if things went wrong.
     */
    void update(final T object) throws DatabaseException;
    
    /**
     * Delete an object by its ID.
     * @param id object's id
     * @throws DatabaseException if things went wrong.
     */
    void deleteById(final K id) throws DatabaseException;
}

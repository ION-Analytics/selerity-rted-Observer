/*
 * (c) Copyright Selerity, Inc. 2009-2012. All rights reserved. This source code is confidential
 * and proprietary information of Selerity Inc. and may be used only by a recipient designated
 * by and for the purposes permitted by Selerity Inc. in writing.  Reproduction of, dissemination
 * of, modifications to or creation of derivative works from this source code, whether in source
 * or binary forms, by any means and in any form or manner, is expressly prohibited, except with
 * the prior written permission of Selerity Inc..  THIS CODE AND INFORMATION ARE PROVIDED "AS IS"
 * WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. This notice may not be
 * removed from the software by any user thereof.
 */

package com.seleritycorp.cs.standalone.commons.db;

import com.seleritycorp.cs.standalone.commons.Utilities;
import com.seleritycorp.cs.standalone.commons.logging.DoesLogging;
import com.seleritycorp.cs.standalone.commons.logging.NullLogger;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;
import org.springframework.transaction.annotation.Transactional;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;
import java.util.logging.Logger;

/**
 * Abstract CRUD DAO.
 *
 * @param <T> Generic object parameter
 */
public abstract class AbstractCrudDao<K,T extends Entity<K>> extends SimpleJdbcDaoSupport implements CrudDao<K,T>, DoesLogging {
    private Logger logger = Logger.getLogger(getClass().getCanonicalName());
    protected final RowMapper rowMapper = new RowMapper();

    abstract public T mapRowFromResultSet(ResultSet resultSet, int i) throws SQLException;

    /**
     * Return a Map based on an instance of T.
     *
     * @param obj object to build parameter map for
     *
     * @return parameter map, which is used by Spring framework to execute queries
     */
    abstract public Map<String, Object> getParameterMap(T obj);

    /**
     * Create a database entry, SQL should use :variables corresponding to map keys.
     *
     * @return SQL for creating the database record
     */
    abstract public String createSql();

    /**
     * Find an database entry, the query SQL should use the ? notation for the id. The results will use the row mapper
     * to populate a T instance.
     *
     * @return SQL for finding the database record
     */
    abstract public String findByIdSql();

    /**
     * Update a database entry, SQL should use the :variables corresponding to paramaterized map keys.
     *
     * @return SQL for updating the database record
     */
    abstract public String updateSql();

    /**
     * Delete a database entry, the query SQL should use the ? notation for the id.
     *
     * @return SQL for deleting the database record by its identifier
     */
    abstract public String deleteByIdSql();

    /**
     * Generate a id for the object or throw an exception if it can not be generated.
     * @param obj
     * @return
     * @throws DatabaseException
     */
    abstract public K generateId(T obj) throws DatabaseException;

    @Transactional
    @Override
    public T create(final T obj) throws DatabaseException {
        if (obj.getId() == null) {
            obj.setId(generateId(obj));
        }
        T result;
        K lastId;
        try {
            int affected = getSimpleJdbcTemplate().update(createSql(), getParameterMap(obj));
            if (affected < 1) {
                throw new Exception("No records were affected! SQL => " + createSql());
            }


            lastId = obj.getId();
            result = findById(lastId);

        } catch (Exception e) {
            getLogger().info("Creation failed: " + e);
            throw new DatabaseException("Could not create.", e);
        }
        if (result == null) {
            throw new DatabaseException("Result shouldn't be null here! \nid =>  " + lastId + "\nSQL => " + createSql());
        }
        return result;
    }

    @Override
    public T findById(final K id) throws DatabaseException {
        try {
            return getSimpleJdbcTemplate().queryForObject(findByIdSql(), rowMapper, Utilities.toString(id));
        } catch (EmptyResultDataAccessException e) {
            return null;
        } catch (Exception e) {
            throw new DatabaseException("Could not findById '" + id + "'.", e);
        }
    }

    @Override
    public void update(final T obj) throws DatabaseException {

        try {
            if (obj.getId() == null) {
                throw new IllegalArgumentException("Object UUID is missing");
            }
            int affected = getSimpleJdbcTemplate().update(updateSql(), getParameterMap(obj));
            if (affected != 1) {
                throw new DatabaseException("Should only affect 1 but affected " + affected);
            }
        } catch (DatabaseException de) {
            throw de;
        } catch (Exception e) {
            throw new DatabaseException("Could not update.", e);
        }
    }

    @Override
    public void deleteById(final K id) throws DatabaseException {
        try {
            getSimpleJdbcTemplate().update(deleteByIdSql(), id.toString());
        } catch (Exception e) {
            throw new DatabaseException("Could not delete by id '" + id + "'.", e);
        }
    }

    @Override
    public Logger getLogger() {
        return logger;
    }

    @Override
    public void setLogger(final Logger logger) {
        if (logger == null) {
            this.logger = new NullLogger();
        } else {
            this.logger = logger;
        }
    }

    /**
     * Row mapper for calendars.
     */
    private class RowMapper implements ParameterizedRowMapper<T> {

        /**
         * Maps a row to a calendar object.
         *
         * @param resultSet result set
         * @param i         index
         * @return calendar
         * @throws java.sql.SQLException if problem mapping row
         */
        public T mapRow(final ResultSet resultSet, final int i) throws SQLException {
            return mapRowFromResultSet(resultSet, i);
        }
    }

}

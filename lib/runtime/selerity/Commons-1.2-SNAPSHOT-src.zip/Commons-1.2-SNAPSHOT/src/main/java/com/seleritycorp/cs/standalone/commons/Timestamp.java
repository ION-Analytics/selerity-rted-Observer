/*
 * © Copyrights Selerity, Inc. 2009-2011. All rights reserved. This source code is confidential
 * and proprietary information of Selerity Inc. and may be used only by a recipient designated
 * by and for the purposes permitted by Selerity Inc. in writing.  Reproduction of, dissemination
 * of, modifications to or creation of derivative works from this source code, whether in source
 * or binary forms, by any means and in any form or manner, is expressly prohibited, except with
 * the prior written permission of Selerity Inc..  THIS CODE AND INFORMATION ARE PROVIDED "AS IS"
 * WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. This notice may not be
 * removed from the software by any user thereof.
 */

package com.seleritycorp.cs.standalone.commons;

import com.selerityfinancial.util.time.Clock;

import java.io.Serializable;
import java.text.ParseException;
import java.util.Calendar;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

/**
 * Represents a point in time. This implementation wraps <code>com.selerityfinancial.util.time.Clock</code> version 1.0 as an object. The
 * time is calculated when the time object gets instantiated, unless it is explicitly passed in as an argument. Internal representation is invariably
 * done in UTC, though convenience methods are implemented to convert to/from the internal representation.
 */
public class Timestamp implements Comparable, Serializable {
    private static final long MAX_NANOSECONDS = 9223285636854775807L;
    private static final long MIN_NANOSECONDS = -5364662400000000000L;

    /** Minimum possible value of a timestamp.  */
    public static final Timestamp MIN_VALUE = new Timestamp(MIN_NANOSECONDS);

    /** Maximum possible value of a timestamp.  */
    public static final Timestamp MAX_VALUE = new Timestamp(MAX_NANOSECONDS);

    /**
     * The time. Yay!
     */
    private final long utcNanos;


    /**
     * Creates a timestamp based on the current time in nanoseconds.
     */
    public Timestamp() {
        utcNanos = Clock.getTimeNanosStatic();
    }

    /**
     * Creates a timestamp based on the specified point in time.
     *
     * @param timeInNanoseconds nanoseconds since epoch
     */
    public Timestamp(long timeInNanoseconds) {
        this.utcNanos = adjustNanoseconds(timeInNanoseconds);
    }

    /**
     * Creates a timestamp from a calendar.
     *
     * @param c calendar
     */
    public Timestamp(Calendar c) {
        this(TimeUnit.MILLISECONDS.toNanos(c.getTimeInMillis()));
    }

    /**
     * Creates a timestamp based on the specified point in time.
     * <p/>
     * The expected format is ISO 8601 long form plus optional nanosecond precision. For example, the string
     * <code>"2010-03-12T17:30:48.123456789"</code> represents March 12, 2010 5:30:48 PM UTC and 123 milliseconds, 456
     * microseconds and 789 nanoseconds.
     *
     * @param timeString standard format Selerity timestamp string
     * @throws java.text.ParseException if the string format is invalid
     */
    public Timestamp(String timeString) throws ParseException {
        if (timeString == null) {
            throw new IllegalArgumentException("Time string argument cannot be null.");
        }
        this.utcNanos = Clock.parseNanoTime(timeString);
    }

    /**
     * Creates a timestamp based on the specified point in time.
     *
     * @param timeString standard format Selerity timestamp string
     * @param timeZone   timezone used in the string
     * @throws ParseException if the string format is invalid
     */
    public Timestamp(String timeString, TimeZone timeZone) throws ParseException {
        if (timeString == null) {
            throw new IllegalArgumentException("Time string argument cannot be null.");
        }
        this.utcNanos = toNanoseconds(timeString, timeZone);
    }

    /**
     * Creates a timestamp based on the specified point in time. This violates the invariant that timestamps should be internally represented in
     * UTC.
     *
     * @param localTime point in time in the given timezone
     * @param timeZone  timezone for the localTime
     * @throws ParseException if the conversion fails
     * @deprecated this is a bad idea to use, because it requires a timestamp that violates the UTC invariant.
     */
    @Deprecated
    public Timestamp(Timestamp localTime, TimeZone timeZone) throws ParseException {
        this(localTime.toString(), timeZone);
    }

    /**
     * Creates a timestamp based on the specified point in time. This violates the invariant that timestamps should be internally represented in
     * UTC.
     *
     * @param localTime  time corresponding to <code>timeZoneId</code>
     * @param timeZoneId time zone of <code>timestamp</code>
     * @throws ParseException if encountered error when converting time
     * @deprecated this is a bad idea to use, because it requires a timestamp that violates the UTC invariant.
     */
    @Deprecated
    public Timestamp(Timestamp localTime, String timeZoneId) throws ParseException {
        this(localTime.toString(), TimeZone.getTimeZone(timeZoneId));
    }


    /**
     * Gets a new Timestamp for current timestamp plus number of days. This method is unsafe because not all days have 24 hours in them. For
     * example, when moving to/from daylight savings time, days will have 23 or 25 hours.
     *
     * @param days number of days to add
     * @return new timestamp with number of days from current timestamp
     */
    @Deprecated
    public Timestamp addDays(int days) {
        return new Timestamp(this.utcNanos + TimeUnit.DAYS.toNanos(days));
    }

    /**
     * Attempts to deal with edge conditions around the time that the timezone changes. The problem is that getting the timezone offset depends
     * on knowing the UTC date already...which requires the value we are trying to calculate. Most of the time, there is not a problem because the
     * timezone doesn't have a different offset except at most twice per year. When the offset changes near to the time string, we might be off -
     * probably by about an hour, but perhaps by less or more.
     *
     * @param nanoTimeString time string
     * @param timeZone       time zone
     * @return UTC nanoseconds
     * @throws ParseException if cannot reconcile time string and time zone
     */
    private long toNanoseconds(String nanoTimeString, TimeZone timeZone) throws ParseException {
        final long nanoTime = Clock.parseNanoTime(nanoTimeString);
        for (int count = 0; count < 4; count++) {
            long nanoseconds = nanoTime - TimeUnit.MILLISECONDS.toNanos(timeZone.getOffset(TimeUnit.NANOSECONDS.toMillis(nanoTime)));
            long offset = TimeUnit.MINUTES.toNanos(30 * count);
            if (isConsistent(nanoTimeString, timeZone, nanoseconds + offset)) {
                return adjustNanoseconds(nanoseconds + offset);
            }
            if (isConsistent(nanoTimeString, timeZone, nanoseconds - offset)) {
                return adjustNanoseconds(nanoseconds - offset);
            }
        }
        throw new ParseException("Cannot reconcile time to timezone!", 0);
    }

    private long adjustNanoseconds(long nanoseconds) {
        if (nanoseconds < MIN_NANOSECONDS) {
            return MIN_NANOSECONDS;
        }
        if (nanoseconds > MAX_NANOSECONDS) {
            return MAX_NANOSECONDS;
        }
        return nanoseconds;
    }

    private boolean isConsistent(String desiredString, TimeZone timeZone, long nanoseconds) {
        try {
            return nanoseconds != adjustNanoseconds(nanoseconds) || (desiredString != null && desiredString.equals(new Timestamp(nanoseconds).toString(timeZone)));
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Gets the time in nanoseconds.
     *
     * @return time in nanoseconds
     */
    public synchronized long getTimeInNanos() {
        return this.utcNanos;
    }

    /**
     * Gets the timestamp in Selerity timestamp format in UTC timezone.
     *
     * @return string in ISO 8601 format
     * @see #toString(TimeZone)
     */
    @Override
    public synchronized String toString() {
        return Clock.formatNanoTime(getTimeInNanos());
    }

    /**
     * Gets the timestamp in Selerity timestamp format in specified timezone. Format is ISO 8601 long form plus optional nanosecond precision.
     * For example, the string <code>"2010-03-12T17:30:48.123456789"</code> represents March 12, 2010 17:30:48 UTC and 123
     * milliseconds, 456 microseconds and 789 nanoseconds.
     *
     * @param timeZone timezone to render using
     * @return string in ISO 8601 format
     */
    public synchronized String toString(TimeZone timeZone) {
        if (timeZone == null) {
            throw new IllegalArgumentException("Timezone may not be null!");
        }
        return Clock.formatNanoTime(getTimeInNanos() + TimeUnit.MILLISECONDS.toNanos(timeZone.getOffset(TimeUnit.NANOSECONDS.toMillis(getTimeInNanos()))));
    }

    /**
     * Gets the Timestamp in the specified timezone.
     *
     * @param timeZone timezone to render using
     * @return <code>Timestamp</code> in the given <code>TimeZone</code>
     * @throws ParseException if conversion fails
     */
    public Timestamp toTimestamp(TimeZone timeZone) throws ParseException {
        String timeInString = this.toString(timeZone);
        return new Timestamp(timeInString);
    }

    /**
     * Gets the Timestamp in the specified timezone.
     *
     * @param timeZoneId timezone to render using
     * @return <code>Timestamp</code> in the given <code>TimeZone</code>
     * @throws ParseException if conversion fails
     */
    public Timestamp toTimestamp(String timeZoneId) throws ParseException {
        String timeInString = this.toString(TimeZone.getTimeZone(timeZoneId));
        return new Timestamp(timeInString);
    }

    @Override
    public boolean equals(Object o) {
        if (o instanceof Timestamp) {
            Timestamp that = (Timestamp) o;
            return this.getTimeInNanos() == that.getTimeInNanos();
        } else {
            return false;
        }
    }

    public int compareTo(Object o) {
        if (o instanceof Timestamp) {
            Timestamp that = (Timestamp) o;
            Long thisLong = this.getTimeInNanos();
            Long thatLong = that.getTimeInNanos();
            return thisLong.compareTo(thatLong);
        } else {
            return -1;
        }
    }

}


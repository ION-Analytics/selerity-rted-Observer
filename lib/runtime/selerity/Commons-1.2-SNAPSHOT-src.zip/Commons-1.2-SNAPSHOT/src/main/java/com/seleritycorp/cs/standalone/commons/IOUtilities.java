package com.seleritycorp.cs.standalone.commons;

import java.io.*;

/**
 * Some basic IO Utilities.
 */
public abstract class IOUtilities {
    private static final int READ_BUFFER_SIZE = 6 * 1024;  // Last I read evil performance started around 8K....

    private IOUtilities() { }

    public static StringBuilder readInputStream(final InputStream stream) throws IOException {
        return readInputStream(stream, null);
    }
    
    public static InputStream getResourceAsStream(String resource) {
        return  getResourceAsStream(null, resource);
    }

    public static InputStream getResourceAsStream(Class c, String resource) {
        ClassLoader classLoader = (c == null) ? ClassLoader.getSystemClassLoader() : c.getClassLoader();

        InputStream stream =  classLoader.getResourceAsStream(resource);
        if (stream != null) {
            return stream;
        }

        // Couldn't be pulled by the class loader, maybe it's just a file
        try {
            stream = new FileInputStream(resource);
        } catch (FileNotFoundException e) {
            return null;
        }

        return stream;
    }

    public static StringBuilder readInputStream(final InputStream stream, final String encoding) throws IOException {
        final char[] readBuffer = new char[READ_BUFFER_SIZE];
        final StringBuilder buffer = new StringBuilder();
        int readCount;

        final InputStreamReader in = new InputStreamReader(stream, encoding == null ? "UTF-8" : encoding);
            try {
                while (true) {
                    readCount = in.read(readBuffer, 0, READ_BUFFER_SIZE);
                    if (readCount == -1) {
                        break;
                    }
                    buffer.append(readBuffer, 0, readCount);
                }
            } finally {
                in.close();
            }
        return buffer;
    }
}

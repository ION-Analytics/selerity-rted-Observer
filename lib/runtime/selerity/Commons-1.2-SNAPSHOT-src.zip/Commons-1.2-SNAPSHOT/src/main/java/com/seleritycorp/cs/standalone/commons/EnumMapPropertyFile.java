/*
 * (c) Copyright Selerity, Inc. 2009-2012. All rights reserved. This source code is confidential
 * and proprietary information of Selerity Inc. and may be used only by a recipient designated
 * by and for the purposes permitted by Selerity Inc. in writing.  Reproduction of, dissemination
 * of, modifications to or creation of derivative works from this source code, whether in source
 * or binary forms, by any means and in any form or manner, is expressly prohibited, except with
 * the prior written permission of Selerity Inc..  THIS CODE AND INFORMATION ARE PROVIDED "AS IS"
 * WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. This notice may not be
 * removed from the software by any user thereof.
 */

package com.seleritycorp.cs.standalone.commons;

import java.io.IOException;
import java.io.InputStream;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.Properties;
import java.util.Set;
import java.util.logging.Logger;

/**
 * A Map with an Enum key that loads its string values from a properties file.
 */
public class EnumMapPropertyFile<K extends Enum<K>> extends EnumMap<K, String> {
    public EnumMapPropertyFile(Class<K> kClass) {
        this(kClass, System.getProperty("config.properties", "config.properties"));
    }

    public EnumMapPropertyFile(Class<K> kClass, String properties) {
        super(kClass);

        final Properties loaded = new Properties();
        try {
            InputStream stream = IOUtilities.getResourceAsStream(properties);
            if (stream == null) {
                Logger.getLogger(EnumMapPropertyFile.class.getName()).warning("Failed finding " + properties);
            } else {
                loaded.load(IOUtilities.getResourceAsStream(properties));
            }
        } catch (IOException e) {
            Logger.getLogger(EnumMapPropertyFile.class.getName()).warning("Failed loading " + properties + ": " + e);
        }

        Set<K> values = EnumSet.allOf(kClass);
        for (K k : values) {
            final String value = loaded.getProperty(k.name());
            if (value != null) {
                this.put(k, value);
            }
        }
    }
}

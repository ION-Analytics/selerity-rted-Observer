package com.seleritycorp.cs.standalone.commons;

/**
 *  Utility interface to provide a standard way to modify a string based on contextual information.
 */
public interface StringDecorator<C> {
    /**
     * Decorate/modify a string based on some contextual information.
     * @param string the string to decorate.
     * @param context the context information to modify the string based on.
     * @return The new enhanced string.
     */
    String decorate(final String string, final C context);
}

/*
 * (c) Copyright Selerity, Inc. 2009-2012. All rights reserved. This source code is confidential
 * and proprietary information of Selerity Inc. and may be used only by a recipient designated
 * by and for the purposes permitted by Selerity Inc. in writing.  Reproduction of, dissemination
 * of, modifications to or creation of derivative works from this source code, whether in source
 * or binary forms, by any means and in any form or manner, is expressly prohibited, except with
 * the prior written permission of Selerity Inc..  THIS CODE AND INFORMATION ARE PROVIDED "AS IS"
 * WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. This notice may not be
 * removed from the software by any user thereof.
 */

package com.seleritycorp.cs.standalone.commons;

import com.seleritycorp.cs.standalone.commons.logging.DoesLoggingImpl;

import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;

/**
 * A class with a periodic task associated that will retry.
 */
abstract public class PeriodicTask extends DoesLoggingImpl {
    private static final long MAX_RETRIES = 10L;
    private final Timer timer;
    private final TimeUnit unit;
    private final long delay;

    protected PeriodicTask(TimeUnit unit, long duration) {
        this(unit, duration, duration / MAX_RETRIES);
    }

    protected PeriodicTask(TimeUnit unit, long duration, long initialDelay) {
        this.unit = unit;
        timer = new Timer(this.getClass().getSimpleName(), true);
        timer.schedule(new PeriodicTaskCaller(), unit.toMillis(initialDelay), unit.toMillis(duration));
        delay = Math.min(initialDelay, duration / MAX_RETRIES);
        getLogger().info("Periodic task running " + duration + " " + unit + " with " + delay + " " + unit + " delay retry on failure.");
    }

    abstract protected void periodicTask() throws Exception;

    public Timer getTimer() {
        return timer;
    }

    /**
     * Task to reload tickers.
     */
    private class PeriodicTaskCaller extends TimerTask {

        @Override
        public void run() {
            int retries = 0;

            while (retries < MAX_RETRIES) {
                try {
                    if (retries > 0) {
                        unit.sleep(delay);
                    }
                    getLogger().info("running periodicTask");
                    periodicTask();
                    break;
                } catch (Exception e) {
                    retries++;
                    getLogger().log(Level.WARNING, "Task failed. Retry " + retries + " will be attempted in " + delay + " " + unit, e);
                }
            }
        }
    }
}

/*
 * © Copyrights Selerity, Inc. 2009-2011. All rights reserved. This source code is confidential 
 * and proprietary information of Selerity Inc. and may be used only by a recipient designated 
 * by and for the purposes permitted by Selerity Inc. in writing.  Reproduction of, dissemination 
 * of, modifications to or creation of derivative works from this source code, whether in source 
 * or binary forms, by any means and in any form or manner, is expressly prohibited, except with 
 * the prior written permission of Selerity Inc..  THIS CODE AND INFORMATION ARE PROVIDED "AS IS"
 * WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. This notice may not be 
 * removed from the software by any user thereof.
 */

package com.seleritycorp.cs.standalone.commons;

import com.selerityfinancial.util.time.Clock;
import org.junit.AfterClass;
import org.junit.Test;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import static org.junit.Assert.*;

/**
 * Tests the core services date class.
 */
public class TimestampTest {

    @AfterClass
    public static void testAfterClass() {
        System.out.println("MAX: " + Timestamp.MAX_VALUE + " = " + Timestamp.MAX_VALUE.getTimeInNanos());
        System.out.println("MIN: " + Timestamp.MIN_VALUE + " = " + Timestamp.MIN_VALUE.getTimeInNanos());
    }

    @Test
    public void testNew1() throws Exception {
        Utilities.consoleBanner(this, "new #1");
        Date before = new Date();
        Thread.sleep(1);
        Timestamp instance = new Timestamp();
        Thread.sleep(1);
        Date after = new Date();
        assertTrue(before.getTime() <= TimeUnit.NANOSECONDS.toMillis(instance.getTimeInNanos()));
        assertTrue(after.getTime() >=  TimeUnit.NANOSECONDS.toMillis(instance.getTimeInNanos()));
    }

    @Test
    public void testNew2() throws Exception {
        Utilities.consoleBanner(this, "new #2");
        Calendar cal = Calendar.getInstance();
        cal.setTimeZone(TimeZone.getTimeZone("UTC"));
        Timestamp ts = new Timestamp(cal);
        assertEquals(cal.getTimeInMillis(), TimeUnit.NANOSECONDS.toMillis(ts.getTimeInNanos()));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testNew3() throws Exception {
        Utilities.consoleBanner(this, "new #3");
        Timestamp ts = new Timestamp("3000-02-04T09:16:25.037000000");
        assertTrue("The statement above should raise an exception.", false);
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testSelectedConstructors() {
        boolean expectedException;

        // Throw some bad arguements at Timestamp constructors to insure they fail

        expectedException = false;
        try {
            new Timestamp(null, "Americas/Dever");
        } catch (Exception e) {
            expectedException = true;
        }
        assertTrue(expectedException);

        expectedException = false;
        try {
            Timestamp seed = new Timestamp();
            new Timestamp(seed, (String) null);
        } catch (Exception e) {
            expectedException = true;
        }
        assertTrue(expectedException);
    }

    @Test
    public void testSelectedToTimestamp() {
        boolean expectedException;

        // Throw some bad arguements at toTimestamp to insure they fail

        expectedException = false;
        try {
            Timestamp ts = new Timestamp();
            ts.toTimestamp((String) null);
        } catch (Exception e) {
            expectedException = true;
        }
        assertTrue(expectedException);
    }

    @Test
    public void testToString1() {
        Utilities.consoleBanner(this, "toString 1");
        Timestamp instance = new Timestamp(986730123768956734L);
        assertEquals("2001-04-08T11:42:03.768956734", instance.toString());
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testAddDays() throws ParseException {
        Timestamp t1 = new Timestamp("2010-01-20T12:30:00.000000000");
        Timestamp instance = t1.addDays(5);
        Timestamp t2 = new Timestamp("2010-01-25T12:30:00.000000000");
        assertEquals(instance.getTimeInNanos(), t2.getTimeInNanos());
    }

    @Test
    public void testToString2() {
        Utilities.consoleBanner(this, "toString 2");
        Timestamp instance = new Timestamp(986730123768956734L);
        assertEquals("2001-04-08T11:42:03.768956734", instance.toString());
        assertEquals("2001-04-08T11:42:03.768956734", instance.toString(TimeZone.getTimeZone("UTC")));
    }

    @Test
    public void testToString3() {
        Utilities.consoleBanner(this, "toString 3");
        Calendar cal = Calendar.getInstance();
        Timestamp ts = new Timestamp(TimeUnit.MILLISECONDS.toNanos(cal.getTimeInMillis()));
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");
        String expected = df.format(cal.getTimeInMillis());
        String actual = ts.toString(cal.getTimeZone());
        actual = actual.substring(0, actual.indexOf('.') + 4);
        assertEquals(expected, actual);
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testToTimestamp1() throws Exception {
        Utilities.consoleBanner(this, "toTimestamp1");
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");
        DateFormat human = new SimpleDateFormat("M/d/yyyy k:mm:ss a zzz");
        String[] zones = getTimeZones();
        for (String zone : zones) {
            for (int month = 0; month < 12; month++) {
                for (int date = 0; date < 31; date++) {
                    for (int hour = 0; hour < 24; hour++) {

                        // set up the calendar
                        Calendar cal = Calendar.getInstance();
                        cal.add(Calendar.MONTH, month);
                        cal.add(Calendar.HOUR, hour);
                        cal.add(Calendar.DATE, date);
                        cal.add(Calendar.MINUTE, 15);
                        cal.add(Calendar.MILLISECOND, (int) (100000.0 * Math.random()));
                        cal.setTimeZone(TimeZone.getTimeZone(zone));

                        // set date parsers
                        df.setTimeZone(cal.getTimeZone());
                        human.setTimeZone(cal.getTimeZone());

                        // check toTimestamp conversions
                        Timestamp ts1 = new Timestamp(TimeUnit.MILLISECONDS.toNanos(cal.getTimeInMillis()));
                        String expected = df.format(cal.getTimeInMillis());
                        Timestamp actualTs = ts1.toTimestamp(cal.getTimeZone());
                        String actual = actualTs.toString();
                        actual = actual.substring(0, actual.indexOf('.') + 4);
                        assertEquals("Timezone " + cal.getTimeZone().getID() + " causes a mismatch for to-string output.", expected, actual);

                        // check constructor conversions
                        Timestamp ts2 = new Timestamp(ts1.toTimestamp(cal.getTimeZone()), cal.getTimeZone());
                        assertEquals(
                                "Timezone " + cal.getTimeZone().getID() + " causes a mismatch for constructor at time " + human.format(cal.getTime()) + "",
                                ts1.toString(cal.getTimeZone()),
                                ts2.toString(cal.getTimeZone())
                        );

                    }
                }
            }
        }
    }

    private String[] getTimeZones() {
        return new String[]{
                "UTC",
                "America/Los_Angeles",
                "America/Phoenix",
                "America/Denver",
                "America/Chicago",
                "America/New_York",
                "Europe/London",
                "Asia/Hong_Kong"
        };
    }

    @Test
    public void testToString4() throws Exception {
        Utilities.consoleBanner(this, "toString 4");
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");
        DateFormat human = new SimpleDateFormat("M/d/yyyy k:mm:ss a zzz");
        String[] zones = getTimeZones();
        for (String zone : zones) {
            for (int month = 0; month < 12; month++) {
                for (int date = 0; date < 31; date++) {
                    for (int hour = 0; hour < 24; hour++) {

                        // set up the calendar
                        Calendar cal = Calendar.getInstance();
                        cal.add(Calendar.MONTH, month);
                        cal.add(Calendar.HOUR, hour);
                        cal.add(Calendar.DATE, date);
                        cal.add(Calendar.MINUTE, 15);
                        cal.add(Calendar.MILLISECOND, (int) (100000.0 * Math.random()));
                        cal.setTimeZone(TimeZone.getTimeZone(zone));

                        // set date parsers
                        df.setTimeZone(cal.getTimeZone());
                        human.setTimeZone(cal.getTimeZone());

                        // check toString conversions
                        Timestamp ts1 = new Timestamp(TimeUnit.MILLISECONDS.toNanos(cal.getTimeInMillis()));
                        String expected = df.format(cal.getTimeInMillis());
                        String actual = ts1.toString(cal.getTimeZone());
                        actual = actual.substring(0, actual.indexOf('.') + 4);
                        assertEquals("Timezone " + cal.getTimeZone().getID() + " causes a mismatch for to-string output.", expected, actual);

                        // check constructor conversions
                        Timestamp ts2 = new Timestamp(ts1.toString(cal.getTimeZone()), cal.getTimeZone());
                        assertEquals(
                                "Timezone " + cal.getTimeZone().getID() + " causes a mismatch for constructor at time " + human.format(cal.getTime()) + "",
                                ts1.toString(cal.getTimeZone()),
                                ts2.toString(cal.getTimeZone())
                        );

                    }
                }
            }
        }
    }

    @Test
    public void testToString5() throws Exception {
        Utilities.consoleBanner(this, "toString 5");

        // testing to replicate problem sometimes seen in more complex code where exception gets thrown in date formatting
        for (int i = 0; i < 100; i++) {
            assertNotNull(new Timestamp().toString());
        }

    }

    @Test
    public void testGetTimeInNanos() {
        Utilities.consoleBanner(this, "getTimeInNanos");
        Timestamp instance = new Timestamp(986730123768956734L);
        assertEquals(986730123768956734L, instance.getTimeInNanos());
    }

    /**
     * Prints reference output and does not perform any assertions.
     */
    @Test
    public void testReferenceOutput() {
        Utilities.consoleBanner(this, "REFERENCE OUTPUT");
        printDebug(new Timestamp());
        printDebug(new Timestamp(Clock.NANOS_PER_WEEK * 52 * 40));
        printDebug(new Timestamp(0));
    }

    @Test
    public void testMin() {
        Utilities.consoleBanner(this, "MIN_VALUE");
        testFormat(Timestamp.MIN_VALUE);
    }

    @Test
    public void testMax() {
        Utilities.consoleBanner(this, "MAX_VALUE");
        testFormat(Timestamp.MAX_VALUE);
    }

    @Test
    public void testCompareTo1() throws Exception {
        Utilities.consoleBanner(this, "testCompareTo 1");
        Timestamp t1 = new Timestamp();
        Thread.sleep(2);
        Timestamp t2 = new Timestamp();
        assertEquals(signum(t1.toString().compareTo(t2.toString())), signum(t1.compareTo(t2)));
    }

    @Test
    public void testCompareTo2() throws Exception {
        Utilities.consoleBanner(this, "testCompareTo 2");
        Timestamp t1 = new Timestamp();
        assertEquals(signum(t1.toString().compareTo(t1.toString())), signum(t1.compareTo(t1)));
    }

    @Test
    public void testCompareTo3() throws Exception {
        Utilities.consoleBanner(this, "testCompareTo 3");
        Timestamp t1 = new Timestamp();
        Thread.sleep(2);
        Timestamp t2 = new Timestamp();
        assertEquals(signum(t2.toString().compareTo(t1.toString())), signum(t2.compareTo(t1)));
    }

    @Test
    public void testCompareTo4() throws Exception {
        Utilities.consoleBanner(this, "testCompareTo 4");
        Timestamp t1 = new Timestamp("2010-01-27T12:30:00.000000000");
        Timestamp t2 = new Timestamp("2010-01-25T12:00:00.000000000");
        assertEquals(signum(t2.toString().compareTo(t1.toString())), signum(t2.compareTo(t1)));
    }

    @Test
    public void testCompareTo5() throws Exception {
        Utilities.consoleBanner(this, "testCompareTo 5");
        Timestamp t1 = new Timestamp("2010-01-27T12:30:00.000000000");
        Timestamp t2 = new Timestamp("2010-01-25T12:00:00.000000000");
        assertEquals(signum(t1.toString().compareTo(t2.toString())), signum(t1.compareTo(t2)));
    }

    @Test
    public void testMakeReallyBig1() throws Exception {
        Utilities.consoleBanner(this, "big #1");
        assertEquals(Timestamp.MAX_VALUE, new Timestamp(Long.MAX_VALUE));
    }

    @Test
    public void testMakeReallyBig2() throws Exception {
        Utilities.consoleBanner(this, "big #2");
        assertEquals(Timestamp.MAX_VALUE, new Timestamp(Timestamp.MAX_VALUE.toString(), TimeZone.getTimeZone("America/New_York")));
    }

    @Test
    public void testMakeReallySmall1() throws Exception {
        Utilities.consoleBanner(this, "small #1");
        assertEquals(Timestamp.MIN_VALUE, new Timestamp(Long.MIN_VALUE));
    }

    @Test
    public void testMakeReallySmall2() throws Exception {
        Utilities.consoleBanner(this, "small #2");
        assertEquals(Timestamp.MIN_VALUE, new Timestamp(Timestamp.MIN_VALUE.toString(), TimeZone.getTimeZone("Europe/Berlin")));
    }

    private void testFormat(Timestamp t) {
        int i = 0;
        String errorMessage = "Timestamp invalid: " + t;
        for (char c : t.toString().toCharArray()) {
            if (i == 4 || i == 7) {
                assertEquals(errorMessage, '-', c);
            } else if (i == 10) {
                assertEquals(errorMessage, 'T', c);
            } else if (i == 13 || i == 16) {
                assertEquals(errorMessage, ':', c);
            } else if (i == 19) {
                assertEquals(errorMessage, '.', c);
            } else {
                assertTrue(errorMessage, Character.isDigit(c));
            }
            i++;
        }

    }

    private int signum(int i) {
        if (i > 0) {
            return 1;
        } else if (i < 0) {
            return -1;
        } else {
            return 0;
        }
    }

    private void printDebug(Timestamp date) {
        System.out.println("  '" + date + "' ==> " + date.getTimeInNanos());
    }


}

/*
 * (c) Copyright Selerity, Inc. 2009-2012. All rights reserved. This source code is confidential
 * and proprietary information of Selerity Inc. and may be used only by a recipient designated
 * by and for the purposes permitted by Selerity Inc. in writing.  Reproduction of, dissemination
 * of, modifications to or creation of derivative works from this source code, whether in source
 * or binary forms, by any means and in any form or manner, is expressly prohibited, except with
 * the prior written permission of Selerity Inc..  THIS CODE AND INFORMATION ARE PROVIDED "AS IS"
 * WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. This notice may not be
 * removed from the software by any user thereof.
 */

package com.seleritycorp.cs.standalone.commons;

import org.junit.Test;

import static junit.framework.Assert.assertEquals;

/**
 *
 */
public class EnumMapPropertyFileTest {
    private enum Light { RED, AMBER, GREEN };

    @Test
    public void testIt() throws Exception {
        EnumMapPropertyFile<Light> lightsEnumProperties = new EnumMapPropertyFile<Light>(Light.class);

        for (Light light : Light.values()) {
            switch (light) {
                case RED:
                    assertEquals("stop", lightsEnumProperties.get(light));
                    break;
                case AMBER:
                    assertEquals("caution", lightsEnumProperties.get(light));
                    break;
                case GREEN:
                    assertEquals("go", lightsEnumProperties.get(light));
                    break;
            }
        }
    }
}

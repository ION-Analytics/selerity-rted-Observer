package com.seleritycorp.cs.standalone.commons;

import org.junit.Test;

import static com.seleritycorp.cs.standalone.commons.Utilities.consoleBanner;
import static junit.framework.Assert.assertEquals;

public class NullStringDecoratorTest {
    @Test
    public void testNullStringDecorator() throws Exception {
        consoleBanner(this, "Nullstringpattern");

        NullStringDecorator<Object> instance = new NullStringDecorator<Object>();

        assertEquals("foo", instance.decorate("foo", this));
    }
}

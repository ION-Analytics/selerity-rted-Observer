package com.seleritycorp.cs.standalone.commons;

import org.junit.Test;

import java.io.InputStream;

import static com.seleritycorp.cs.standalone.commons.Utilities.consoleBanner;
import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertNotNull;

/**
 *
 */
public class IOUtilitiesTest {
    private static final String CONTENTS = "This is a test.\n";
    @Test
    public void testReadInputStream() throws Exception {
        consoleBanner(this, "read stream.");
        final InputStream stream = this.getClass().getClassLoader().getResourceAsStream("sample.txt");
        assertNotNull(stream);
        StringBuilder stringBuilder = IOUtilities.readInputStream(stream);
        assertNotNull(stringBuilder);
        assertEquals(CONTENTS, stringBuilder.toString());
    }
    
    @Test
    public void testGetResourceAsStream() throws Exception {
        final InputStream stream = IOUtilities.getResourceAsStream("sample.txt");
        assertNotNull(stream);
        StringBuilder stringBuilder = IOUtilities.readInputStream(stream);
        assertNotNull(stringBuilder);
        assertEquals(CONTENTS, stringBuilder.toString());
    }
}

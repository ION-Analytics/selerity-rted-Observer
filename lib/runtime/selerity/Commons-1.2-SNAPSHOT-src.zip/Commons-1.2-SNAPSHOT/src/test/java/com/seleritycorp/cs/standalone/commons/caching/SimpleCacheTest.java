/*
 * (c) Copyright Selerity, Inc. 2009-2012. All rights reserved. This source code is confidential
 * and proprietary information of Selerity Inc. and may be used only by a recipient designated
 * by and for the purposes permitted by Selerity Inc. in writing.  Reproduction of, dissemination
 * of, modifications to or creation of derivative works from this source code, whether in source
 * or binary forms, by any means and in any form or manner, is expressly prohibited, except with
 * the prior written permission of Selerity Inc..  THIS CODE AND INFORMATION ARE PROVIDED "AS IS"
 * WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. This notice may not be
 * removed from the software by any user thereof.
 */

package com.seleritycorp.cs.standalone.commons.caching;

import org.junit.Before;
import org.junit.Test;

import java.util.concurrent.TimeUnit;

import static com.seleritycorp.cs.standalone.commons.Utilities.consoleBanner;
import static junit.framework.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

/**
 *
 */
public class SimpleCacheTest {
    private static final int MAX = 4;
    private SimpleCache<Integer, Integer> cache;
    private SimpleCache<String, String> loadingCache;

    @Before
    public void setUp() throws Exception {
        cache = new SimpleCache<>();
        cache.setMaximumSize(MAX);

        loadingCache = new SimpleCache<>(null,new Lookup<String, String>() {
            @Override
            public String get(String key) {
                return key.toUpperCase();
            }
        },1);
    }

    @Test
       public void testSanity() throws Exception {
           consoleBanner(this,"sanity");
           cache.put(10, 100);
           assertEquals((Integer) 100, cache.get(10));
           assertNull(cache.get(5));
       }

    @Test
    public void testLimitCache() throws Exception {
        consoleBanner(this, "Test size limit");

        // test the simple scenario where it should push an item off end
        for (int x = 0; x <= MAX; x++) {
            TimeUnit.MICROSECONDS.sleep(2);
            cache.put(x, x);
        }

        assertEquals(MAX, cache.size());
        assertNotNull(cache.get(MAX));
    }

    @Test
    public void testReallyLru() throws Exception {
        consoleBanner(this, "test LRU");

        // test the simple scenario where it should push an item off end
        for (int x = 0; x < MAX; x++) {
            cache.put(x, x);
            TimeUnit.MILLISECONDS.sleep(1);
        }

        assertEquals(MAX, cache.size());
        assertNotNull(cache.get(0));
        assertNotNull(cache.get(MAX - 1));

        /*
         Made it here, the cache is loaded and we've accessed position 0. If this is LRU and we add one more
         0 should not be ejected, 1 should be.
        */

        cache.put(100, 100);
        assertNotNull(cache.get(0));
        System.out.println();
        assertNull(cache.get(1));
    }

    @Test
    public void testSelfPopulating() {
        consoleBanner(this, "Self Populating");
        assertNotNull(loadingCache);
        assertEquals("AAA", loadingCache.get("aaa"));
    }

    @Test
    public void testCacheAging() throws Exception {
        consoleBanner(this, "Aging");

        cache.setTimeToLiveUnits(TimeUnit.SECONDS);
        cache.setTimeToLive(1);
        cache.put(20, 20);
        assertEquals((Integer)20, cache.get(20));
        TimeUnit.SECONDS.sleep(2);
        assertNull(cache.get(20));
      }

}

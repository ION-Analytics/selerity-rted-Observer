Commons stores the common utilities classes that Core Services modules use.

/*
 * (c) Copyright Selerity, Inc. 2009-2013. All rights reserved. This source code is confidential
 * and proprietary information of Selerity Inc. and may be used only by a recipient designated
 * by and for the purposes permitted by Selerity Inc. in writing.  Reproduction of, dissemination
 * of, modifications to or creation of derivative works from this source code, whether in source
 * or binary forms, by any means and in any form or manner, is expressly prohibited, except with
 * the prior written permission of Selerity Inc..  THIS CODE AND INFORMATION ARE PROVIDED "AS IS"
 * WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. This notice may not be
 * removed from the software by any user thereof.
 */

package com.seleritycorp.cs.standalone.commons.util.function;

import com.seleritycorp.cs.standalone.commons.Utilities;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

/**
 * Operations based on a Consumer.
 */
public class IterableOps {

    /**
     * Traverse an iterable, accepting each value with a consumer.
     *
     * @param iterable The iterable to traverse
     * @param consumer The consumer to accept each value
     */
    public static <T> void forEach(Iterable<T> iterable, Consumer<? super T> consumer) {
        for (T t : iterable) {
            consumer.accept(t);
        }
    }

    /**
     * Outputs a collection of object as a string. If the value of the argument is <code>null</code> then the result is a <code>null</code> string.
     *
     * @param from objects to be converted to string form
     * @return string of the object, <code>null</code> iff the object given is <code>null</code>
     */
    @Nullable
    public static <T> List<String> iterableToStrings(@NotNull final Iterable<T> from) {
        try {
            return IterableOps.map(from, new Function<T, String>() {
                @Override
                public String apply(Object o) {
                    return Utilities.toString(o);
                }
            });
        } catch (Exception e) {
            throw new IllegalArgumentException("String conversion failed: " + e);
        }
    }

    /**
     * Map the elements of an iterable to a list applying a function to each.
     *
     * @param from     the iterable to draw from
     * @param function the function to apply
     * @param <T>      the original element type
     * @param <R>      the new element type
     * @return the list of resultant elements
     */
    @Nullable
    public static <T, R> List<R> map(@Nullable Iterable<T> from, @NotNull Function<T, R> function) {
        if (from == null) {
            return null;
        }

        final List<R> results = new ArrayList<>();

        for (T t : from) {
            results.add(function.apply(t));
        }
        return results;
    }

    @Nullable
    public static <T> List<T> filter(@Nullable Iterable<T> from, @NotNull Predicate<T> predicate) {
        if (from == null) {
            return null;
        }

        List<T> toList = new ArrayList<>();
        for (T t : from) {
            if (predicate.test(t)) {
                toList.add(t);
            }
        }

        return toList;
    }
}

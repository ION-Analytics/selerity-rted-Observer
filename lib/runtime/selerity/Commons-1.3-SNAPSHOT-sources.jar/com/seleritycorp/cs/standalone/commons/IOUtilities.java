/*
 * (c) Copyright Selerity, Inc. 2009-2013. All rights reserved. This source code is confidential
 * and proprietary information of Selerity Inc. and may be used only by a recipient designated
 * by and for the purposes permitted by Selerity Inc. in writing.  Reproduction of, dissemination
 * of, modifications to or creation of derivative works from this source code, whether in source
 * or binary forms, by any means and in any form or manner, is expressly prohibited, except with
 * the prior written permission of Selerity Inc..  THIS CODE AND INFORMATION ARE PROVIDED "AS IS"
 * WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. This notice may not be
 * removed from the software by any user thereof.
 */

package com.seleritycorp.cs.standalone.commons;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import java.io.*;
import java.net.ServerSocket;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.util.logging.Logger;

/**
 * Some basic IO Utilities.
 */
public abstract class IOUtilities {
    public static final int GENERIC_READ_BUFFER_SIZE = 6 * 1024;  // Last I read evil performance started around 8K....
    private static final Logger LOGGER = Logger.getLogger(IOUtilities.class.getName());
    private static final String DEFAULT_JAVA_KEYSTORE_PW = "changeit";

    private IOUtilities() {
    }

    /**
     * Locate a resource in the jar or by url and open a stream to it.
     *
     * @param resource the resource
     * @return the stream
     */
    public static InputStream getResourceAsStream(String resource) {
        return getResourceAsStream(null, resource);
    }

    /**
     * Open a resource located in reference to a specific class as a stream.
     *
     * @param c        the class of the jar to check
     * @param resource the resource
     * @return the stream
     */
    public static InputStream getResourceAsStream(Class<?> c, String resource) {
        ClassLoader classLoader = (c == null) ? ClassLoader.getSystemClassLoader() : c.getClassLoader();

        InputStream stream = classLoader.getResourceAsStream(resource);
        if (stream != null) {
            return stream;
        }

        // Couldn't be pulled by the class loader, maybe it's just a file
        try {
            stream = new FileInputStream(resource);
        } catch (FileNotFoundException e) {
            LOGGER.warning("Resource " + resource + " not found: " + e);
            return null;
        }

        return stream;
    }

    /**
     * Read the contents of a stream to a StringBuilder.
     *
     * @param stream the stream
     * @return a stringbuilder
     * @throws IOException
     */
    public static String readInputStream(final InputStream stream) throws IOException {
        return readInputStream(stream, null);
    }

    /**
     * Read a stream with a specific input encoding.
     *
     * @param inputStream stream
     * @param encoding    encoding
     * @return The stringbuilder
     * @throws IOException
     */
    public static String readInputStream(final InputStream inputStream, final String encoding) throws IOException {
        try (ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
            copyStream(inputStream, outputStream);
            return outputStream.toString(encoding == null ? "UTF-8" : encoding);
        }
    }

    /**
     * Sucks in an input stream and spew it out to a file.
     *
     * @param inputStream    input stream
     * @param outputFilePath absolute path to output file
     * @return the file with content from input stream
     * @throws IOException if anything goes wrong.
     */
    public static File toFile(final InputStream inputStream, final String outputFilePath) throws IOException {
        File outputFile = new File(outputFilePath);
        if (!outputFile.exists() && !outputFile.createNewFile()) {
            throw new IllegalStateException("Cannot create output file " + outputFile);
        }
        try (OutputStream outputStream = new FileOutputStream(outputFile)) {
            copyStream(inputStream, outputStream);
        }
        return outputFile;
    }

    /**
     * Copy data from an input stream to an output stream.
     *
     * @param inputStream  input stream
     * @param outputStream output stream
     * @return number of bytes copied
     * @throws IOException
     */
    public static long copyStream(final InputStream inputStream, final OutputStream outputStream) throws IOException {
        final byte[] readBuffer = new byte[GENERIC_READ_BUFFER_SIZE];
        long readTotal = 0;
        int readCount;

        try (BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(outputStream, GENERIC_READ_BUFFER_SIZE * 5)) {
            while (true) {
                readCount = inputStream.read(readBuffer, 0, GENERIC_READ_BUFFER_SIZE);
                if (readCount == -1) {
                    bufferedOutputStream.flush();
                    break;
                }
                bufferedOutputStream.write(readBuffer, 0, readCount);
                readTotal += readCount;
            }
            return readTotal;
        }
    }

    /**
     * Open a resource and return its contents as a string.
     *
     * @param resource
     * @return
     * @throws IOException
     * @deprecated use getResourceAsString
     */
    @Deprecated
    public static String getResourceAsStringBuilder(String resource) throws IOException {
        return readInputStream(getResourceAsStream(resource));
    }

    /**
     * Open a resource and return its contents as a string.
     *
     * @param resource resource to open
     * @return the contents as a string
     * @throws IOException
     */
    public static String getResourceAsString(String resource) throws IOException {
        return readInputStream(getResourceAsStream(resource));
    }

    /**
     * Return a free port. Is free at the time it was returned but not guaranteed to remain so.
     *
     * @return a free port.
     * @throws IOException If no port can be determined.
     */
    public static int findAvailablePort() throws IOException {
        try (ServerSocket serverSocket = new ServerSocket(0)) {
            return serverSocket.getLocalPort();
        }
    }

    /**
     * Load keyStore from resource before connecting to https server.
     *
     * @param callingClass
     * @param keyStoreName
     * @param password
     * @throws IOException If no port can be determined.
     */
    public static void loadKeyStore(Class<?> callingClass, String keyStoreName, String password) throws IOException {
        try {
            TrustManagerFactory trustManagerFactory = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
            KeyStore keyStore = KeyStore.getInstance(KeyStore.getDefaultType());
            try (InputStream keyStoreStream = getResourceAsStream(callingClass, keyStoreName)) {
                keyStore.load(keyStoreStream, password.toCharArray());
            }
            trustManagerFactory.init(keyStore);
            TrustManager[] trustManagers = trustManagerFactory.getTrustManagers();
            SSLContext ctx = SSLContext.getInstance("TLS");
            ctx.init(null, trustManagers, null);
            HttpsURLConnection.setDefaultSSLSocketFactory(ctx.getSocketFactory());
        } catch (KeyStoreException | KeyManagementException | NoSuchAlgorithmException | CertificateException | IOException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Load keyStore from resource before connecting to https server using default password.
     *
     * @param callingClass
     * @param keyStoreName
     * @throws IOException If no port can be determined.
     */
    public static void loadKeyStore(Class<?> callingClass, String keyStoreName) throws IOException {
        loadKeyStore(callingClass, keyStoreName, DEFAULT_JAVA_KEYSTORE_PW);
    }
}

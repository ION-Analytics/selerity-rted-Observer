/*
 * (c) Copyright Selerity, Inc. 2009-2013. All rights reserved. This source code is confidential
 * and proprietary information of Selerity Inc. and may be used only by a recipient designated
 * by and for the purposes permitted by Selerity Inc. in writing.  Reproduction of, dissemination
 * of, modifications to or creation of derivative works from this source code, whether in source
 * or binary forms, by any means and in any form or manner, is expressly prohibited, except with
 * the prior written permission of Selerity Inc..  THIS CODE AND INFORMATION ARE PROVIDED "AS IS"
 * WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. This notice may not be
 * removed from the software by any user thereof.
 */

package com.seleritycorp.cs.standalone.commons;


import java.text.ParseException;
import java.util.concurrent.TimeUnit;

import static java.lang.Math.min;

/**
 * Defines a rate limit based on points.  The points accumulate in discrete quantities at regular time intervals.
 * Actions which are to be rate-limited must call the usePoints() method to see whether enough points have
 * accumulated to perform the action.
 * <p/>
 * For example: a RateLimiter created with the arguments of maxPoints = 20, incrementalPoints = 10, incrementalMillis = 1000
 * would accumulate 10 points every second (1000 milliseconds) and max out at 20 points.  If some task consumed 5 points on
 * each invocation then that task could never be executed more than 4 times in a short burst and only twice per second over
 * the long run.
 */
public class RateLimiter {
    private final int maxPoints;
    private final int incrementalPoints;
    private final long incrementalMillis;
    private long lastCheckedMillis;
    private int lastPoints;

    /**
     * Constructor
     *
     * @param maxPoints         maximum points
     * @param incrementalPoints increment of points
     * @param timeUnit          time unit for the time parameters
     * @param incrementTime     time in timeUnit before increment
     */
    public RateLimiter(final int maxPoints, final int incrementalPoints,
                       final TimeUnit timeUnit, final long incrementTime) {
        this.maxPoints = maxPoints;
        this.incrementalPoints = incrementalPoints;
        this.incrementalMillis = timeUnit.toMillis(incrementTime);
        this.lastCheckedMillis = System.currentTimeMillis();
        this.lastPoints = maxPoints;
    }

    /**
     * Expects a string like "maxPoints,incrementalPoints,TimeUint,timeIncrement", so for example:
     * 500,100,SECONDS,1
     *
     * @param string the string.
     * @return A RateLimiter
     */
    public static RateLimiter parseRateLimiter(final String string) throws ParseException {
        int position = 0;
        try {
            String[] parts = string.split(",");
            if (parts == null || parts.length != 4) {
                throw new ParseException("Not a valid rateLimiterString: " + string, 0);
            }
            final int maxPoints = Integer.parseInt(parts[0]);
            position += parts[0].length() + 1;
            final int incrementalPoints = Integer.parseInt(parts[1]);
            position += parts[1].length() + 1;
            final TimeUnit timeUnit = TimeUnit.valueOf(parts[2]);
            position += parts[2].length() + 1;
            final int incrementTime = Integer.parseInt(parts[3]);
            return new RateLimiter(maxPoints, incrementalPoints, timeUnit, incrementTime);
        } catch (Throwable t) {
            throw new ParseException("Parsing error: " + t, position);
        }

    }

    /**
     * If enough points have accumulated based on the current system time,
     * then subtracts pointsToUse and returns true.  Otherwise returns
     * false and subtracts nothing.
     *
     * @param pointsToUse int points to use
     * @return @code{boolean} True if enough points have accumulated.
     */
    public synchronized boolean usePoints(final int pointsToUse) {
        return usePoints(pointsToUse, System.currentTimeMillis());
    }

    /**
     * If enough points have accumulated based on the given time,
     * then subtracts pointsToUse and returns true.  Otherwise returns
     * false and subtracts nothing.
     *
     * @param pointsToUse       int points to use
     * @param currentTimeMillis long current time in milliseconds
     * @return @code{boolean} True if enough points have accumulated.
     */
    public synchronized boolean usePoints(final int pointsToUse, final long currentTimeMillis) {
        final long elapsedMillis = currentTimeMillis - lastCheckedMillis;
        final long cycles = elapsedMillis / incrementalMillis;
        lastCheckedMillis = lastCheckedMillis + cycles * incrementalMillis; // this prevents us from missing cycles due to frequent polling
        int newPoints = min(maxPoints, lastPoints + ((int) cycles) * incrementalPoints);
        lastPoints = newPoints;

        if (newPoints < pointsToUse) {
            return false;
        }

        lastPoints -= pointsToUse;
        return true;
    }

    /**
     * Returns the number of accumulated points based on current system time
     * without deducting any.
     *
     * @return @code{int} number of accumulated points
     */
    public synchronized int getPoints() {
        return getPoints(System.currentTimeMillis());
    }

    public int getMaxPoints() {
        return maxPoints;
    }

    public int getIncrementalPoints() {
        return incrementalPoints;
    }

    public long getIncrementalMillis() {
        return incrementalMillis;
    }

    /**
     * Returns the number of accumulated points based on the given time
     * without deducting any.
     *
     * @param currentTimeMillis long current time in milliseconds
     * @return @code{int} number of accumulated points
     */
    public synchronized int getPoints(final long currentTimeMillis) {
        final long elapsedMillis = currentTimeMillis - lastCheckedMillis;
        final long cycles = elapsedMillis / incrementalMillis;
        lastCheckedMillis = lastCheckedMillis + cycles * incrementalMillis; // this prevents us from missing cycles due to frequent polling
        lastPoints = min(maxPoints, lastPoints + ((int) cycles) * incrementalPoints);
        return lastPoints;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("RateLimiter: ");
        sb.append("(maxPoints=").append(maxPoints);
        sb.append(", incrementalPoints=").append(incrementalPoints);
        sb.append(", incrementalMillis=").append(incrementalMillis);
        sb.append(')');
        return sb.toString();
    }
}

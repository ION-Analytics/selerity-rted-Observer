/*
 * (c) Copyright Selerity, Inc. 2009-2013. All rights reserved. This source code is confidential
 * and proprietary information of Selerity Inc. and may be used only by a recipient designated
 * by and for the purposes permitted by Selerity Inc. in writing.  Reproduction of, dissemination
 * of, modifications to or creation of derivative works from this source code, whether in source
 * or binary forms, by any means and in any form or manner, is expressly prohibited, except with
 * the prior written permission of Selerity Inc..  THIS CODE AND INFORMATION ARE PROVIDED "AS IS"
 * WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. This notice may not be
 * removed from the software by any user thereof.
 */

package com.seleritycorp.cs.standalone.commons.logging;

import com.seleritycorp.cs.standalone.commons.DateUtils;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;
import java.util.logging.*;

/**
 * A Daily Rolling JUL logger. The configuration is largely FileHandler compatible, supporting .pattern, .append, .level, .filter and .formatter.
 * <p/>
 * The .pattern is a SimpleDateFormat pattern.
 */
public class DailyRollingFileHandler extends StreamHandler {
    private static final String DEFAULT_PATTERN = "yyyy-MM-dd'.log'";
    private SimpleDateFormat pattern = new SimpleDateFormat(DEFAULT_PATTERN);
    private OutputStream out = null;
    private Boolean append = Boolean.TRUE;
    private long day = 0;

    public DailyRollingFileHandler() {
        configure();
        rollLog();
    }

    private void configure() {
        LogManager manager = LogManager.getLogManager();
        final String cname = getClass().getName();
        String val;

        val = manager.getProperty(cname + ".pattern");
        if (val != null) {
            pattern = new SimpleDateFormat(val.trim());
        }

        pattern.setTimeZone(DateUtils.UTC_TIMEZONE);

        val = manager.getProperty(cname + ".append");
        if (val != null) {
            append = Boolean.parseBoolean(val.trim());
        }

        val = manager.getProperty(cname + ".level");
        if (val == null) {
            setLevel(Level.ALL);
        } else {
            setLevel(Level.parse(val.trim()));
        }

        val = manager.getProperty(cname + ".filter");
        if (val != null) {
            try {
                Class clz = ClassLoader.getSystemClassLoader().loadClass(val);
                setFilter((Filter) clz.newInstance());
            } catch (Exception e) {
                System.err.println("Could not assign filter: " + val);
            }
        }

        val = manager.getProperty(cname + ".formatter");
        if (val == null) {
            setFormatter(new XMLFormatter());
        } else {
            try {
                Class clz = ClassLoader.getSystemClassLoader().loadClass(val);
                setFormatter((Formatter) clz.newInstance());
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        val = manager.getProperty(cname + ".encoding");
        if (val != null) {
            try {
                setEncoding(val.trim());
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    void rollLog() {
        long nowMillis = System.currentTimeMillis();
        long nowDay = TimeUnit.MILLISECONDS.toDays(nowMillis);

        if (nowDay == day) {
            return;
        }

        day = nowDay;
        final String filename = pattern.format(new Date(nowMillis));
        Level oldLevel = getLevel();
        setLevel(Level.OFF);
        close();

        try {
            FileOutputStream fout = new FileOutputStream(filename, append);
            out = new BufferedOutputStream(fout);
            setOutputStream(out);
        } catch (IOException io) {
            System.err.println("Could nor open log file: " + filename);
        }


        setLevel(oldLevel);
    }

    @Override
    public synchronized void close() throws SecurityException {
        super.close();
        try {
            if (out != null) {
                out.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public synchronized void publish(LogRecord record) {
        if (!isLoggable(record)) {
            return;
        }
        rollLog();
        super.publish(record);
        flush();
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("DailyRollingFileHandler{");
        sb.append("pattern=").append(pattern.toPattern());
        sb.append(", append=").append(append);
        sb.append('}');
        return sb.toString();
    }
}

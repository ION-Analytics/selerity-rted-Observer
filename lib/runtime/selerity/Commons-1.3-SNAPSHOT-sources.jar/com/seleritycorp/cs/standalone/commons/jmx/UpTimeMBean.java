/*
 * (c) Copyright Selerity, Inc. 2009-2013. All rights reserved. This source code is confidential
 * and proprietary information of Selerity Inc. and may be used only by a recipient designated
 * by and for the purposes permitted by Selerity Inc. in writing.  Reproduction of, dissemination
 * of, modifications to or creation of derivative works from this source code, whether in source
 * or binary forms, by any means and in any form or manner, is expressly prohibited, except with
 * the prior written permission of Selerity Inc..  THIS CODE AND INFORMATION ARE PROVIDED "AS IS"
 * WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. This notice may not be
 * removed from the software by any user thereof.
 */
package com.seleritycorp.cs.standalone.commons.jmx;

import com.seleritycorp.cs.standalone.commons.Timestamp;
import org.springframework.jmx.export.annotation.ManagedAttribute;
import org.springframework.jmx.export.annotation.ManagedResource;

@ManagedResource(objectName = "com.seleritycorp.cs.standalone.commons.jmx:name=upTime", description = "Expose the upTime of an app.")
public class UpTimeMBean {
    public final static String ATTRIBUTE_NAME = "UpTime";
    private final Timestamp upTime;

    public UpTimeMBean() {
        upTime = new Timestamp();
    }

    @ManagedAttribute(description = "Get the upTime for the app.")
    public String getUpTime() {
        return upTime.toString();
    }
}

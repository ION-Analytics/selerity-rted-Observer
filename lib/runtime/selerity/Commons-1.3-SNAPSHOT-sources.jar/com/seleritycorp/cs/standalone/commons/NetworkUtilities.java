/*
 * (c) Copyright Selerity, Inc. 2009-2013. All rights reserved. This source code is confidential
 * and proprietary information of Selerity Inc. and may be used only by a recipient designated
 * by and for the purposes permitted by Selerity Inc. in writing.  Reproduction of, dissemination
 * of, modifications to or creation of derivative works from this source code, whether in source
 * or binary forms, by any means and in any form or manner, is expressly prohibited, except with
 * the prior written permission of Selerity Inc..  THIS CODE AND INFORMATION ARE PROVIDED "AS IS"
 * WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. This notice may not be
 * removed from the software by any user thereof.
 */

package com.seleritycorp.cs.standalone.commons;

import org.jetbrains.annotations.Nullable;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.Enumeration;
import java.util.logging.Logger;

/**
 * Misc utilities to do with networking.
 */
public class NetworkUtilities {
    private static final Logger LOGGER = Logger.getLogger(NetworkUtilities.class.getName());


    public static NetworkInterface findNetworkInterface() {
        NetworkInterface found = null;
        try {
            // find the network interface with the lowest hash code - this helps us get the same network card every time for a given instance
            Enumeration<NetworkInterface> e = NetworkInterface.getNetworkInterfaces();
            while (e.hasMoreElements()) {
                final NetworkInterface ni = e.nextElement();
                if (ni != null && ni.getHardwareAddress() != null && (found == null || found.hashCode() > ni.hashCode())) {
                    found = ni;
                }
            }
            return found;
        } catch (Exception e) {
            throw new IllegalStateException("Cannot find network interface.", e);
        }
    }

    public static String getHostAddress() {
        InetAddress found = null;

        try {
            final NetworkInterface networkInterface = findNetworkInterface();
            if (networkInterface != null) {
                final Enumeration<InetAddress> inetAddresses = networkInterface.getInetAddresses();
                while (inetAddresses.hasMoreElements()) {
                    final InetAddress inetAddress = inetAddresses.nextElement();

                    if (inetAddress.isLoopbackAddress() || !(inetAddress instanceof Inet4Address)) {
                        continue;
                    }

                    if (found == null || found.hashCode() > inetAddress.hashCode()) {
                        found = inetAddress;
                    }
                }
            }
        } catch (Exception ignored) {
            LOGGER.info("Unable to determine host address");
        }

        return getIpAsString(found);
    }

    @Nullable
    private static String getIpAsString(@Nullable InetAddress address) {
        if (address == null) {
            return null;
        }
        final byte[] ipAddress = address.getAddress();
        final StringBuilder str = new StringBuilder();
        for (int i = 0; i < ipAddress.length; i++) {
            if (i > 0) {
                str.append('.');
            }
            str.append(ipAddress[i] & 0xFF);
        }
        return str.toString();
    }

}

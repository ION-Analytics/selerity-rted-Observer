/*
 * (c) Copyright Selerity, Inc. 2009-2013. All rights reserved. This source code is confidential
 * and proprietary information of Selerity Inc. and may be used only by a recipient designated
 * by and for the purposes permitted by Selerity Inc. in writing.  Reproduction of, dissemination
 * of, modifications to or creation of derivative works from this source code, whether in source
 * or binary forms, by any means and in any form or manner, is expressly prohibited, except with
 * the prior written permission of Selerity Inc..  THIS CODE AND INFORMATION ARE PROVIDED "AS IS"
 * WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. This notice may not be
 * removed from the software by any user thereof.
 */

package com.seleritycorp.cs.standalone.commons;

import org.jetbrains.annotations.NotNull;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Delayed;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * A class that adds elements to a blocking queue with a delay.
 *
 * @param <E> the type of element
 */
public class DelayQueuer<E> extends Thread {

    private static final Logger LOGGER = Logger.getLogger(DelayQueuer.class.getName());

    private final BlockingQueue<E> blockingQueue;
    private final PriorityBlockingQueue<DelayedElement<E>> priorityQueue;

    public DelayQueuer(BlockingQueue<E> blockingQueue) {
        this.blockingQueue = blockingQueue;
        this.priorityQueue = new PriorityBlockingQueue<>();
    }

    @SuppressWarnings("unchecked")
    public void add(E e, long delayMillis) {
        priorityQueue.add(new DelayedElement(e, System.currentTimeMillis() + delayMillis));
        synchronized (priorityQueue) {
            priorityQueue.notify();
        }
    }

    public void run() {
        while (true) {
            try {
                final DelayedElement<E> delayedElement = priorityQueue.take();
                final long delayMillis = delayedElement.getDelay(TimeUnit.MILLISECONDS);
                if (delayMillis > 0) {
                    synchronized (priorityQueue) {
                        priorityQueue.wait(delayMillis);
                    }
                }
                if (delayedElement.getDelay(TimeUnit.MILLISECONDS) > 0) {
                    priorityQueue.add(delayedElement);
                } else {
                    blockingQueue.add(delayedElement.get());
                }
            } catch (Exception e) {
                LOGGER.log(Level.SEVERE, "Error running DelayQueuer.", e);
            }
        }
    }

    private class DelayedElement<E> implements Delayed {

        private final E e;
        private final long elapsedDelayTimeMillis;

        public DelayedElement(E e, long elapsedDelayTimeMillis) {
            this.e = e;
            this.elapsedDelayTimeMillis = elapsedDelayTimeMillis;
        }

        public E get() {
            return e;
        }

        @Override
        public long getDelay(@NotNull TimeUnit timeUnit) {
            return TimeUnit.MILLISECONDS.convert(elapsedDelayTimeMillis - System.currentTimeMillis(), timeUnit);
        }

        @Override
        public int compareTo(Delayed d) {
            return Long.compare(getDelay(TimeUnit.MILLISECONDS), d.getDelay(TimeUnit.MILLISECONDS));
        }
    }
}

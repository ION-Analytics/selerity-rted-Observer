/*
 * (c) Copyright Selerity, Inc. 2009-2013. All rights reserved. This source code is confidential
 * and proprietary information of Selerity Inc. and may be used only by a recipient designated
 * by and for the purposes permitted by Selerity Inc. in writing.  Reproduction of, dissemination
 * of, modifications to or creation of derivative works from this source code, whether in source
 * or binary forms, by any means and in any form or manner, is expressly prohibited, except with
 * the prior written permission of Selerity Inc..  THIS CODE AND INFORMATION ARE PROVIDED "AS IS"
 * WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. This notice may not be
 * removed from the software by any user thereof.
 */

package com.seleritycorp.cs.standalone.commons.caching;

import com.seleritycorp.cs.standalone.commons.logging.DoesLoggingImpl;
import org.jetbrains.annotations.NotNull;

import java.util.Objects;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

/**
 * A facade to allow a Lookup to be used as a Future.
 */
public class LookupFuture<K, V> extends DoesLoggingImpl implements Future<V> {
    private final Lookup<K, V> lookup;
    private final K key;
    private final AtomicReference<V> value = new AtomicReference<>();
    private final AtomicBoolean done = new AtomicBoolean(false);

    public LookupFuture(@NotNull Lookup<K, V> lookup, K key) {
        Objects.requireNonNull(lookup, "Must be a non null lookup function");
        this.lookup = lookup;
        this.key = key;
        getLogger().info("Kicking off a lookup " + this.toString());
    }

    @Override
    public boolean cancel(boolean mayInterruptIfRunning) {
        return false;
    }

    @Override
    public boolean isCancelled() {
        return false;
    }

    @Override
    public boolean isDone() {
        return done.get();
    }

    @Override
    public V get() throws InterruptedException, ExecutionException {
        doLookup();
        return value.get();
    }

    @Override
    public V get(long timeout, TimeUnit unit) throws InterruptedException, ExecutionException, TimeoutException {
        throw new UnsupportedOperationException("Method not implemented");
    }

    private synchronized void doLookup() {
        if (done.get()) {
            return;
        }
        value.set(lookup.get(key));
        done.set(true);
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("LookupFuture{");
        sb.append(", key=").append(key);
        sb.append('}');
        return sb.toString();
    }
}

/*
 * (c) Copyright Selerity, Inc. 2009-2013. All rights reserved. This source code is confidential
 * and proprietary information of Selerity Inc. and may be used only by a recipient designated
 * by and for the purposes permitted by Selerity Inc. in writing.  Reproduction of, dissemination
 * of, modifications to or creation of derivative works from this source code, whether in source
 * or binary forms, by any means and in any form or manner, is expressly prohibited, except with
 * the prior written permission of Selerity Inc..  THIS CODE AND INFORMATION ARE PROVIDED "AS IS"
 * WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. This notice may not be
 * removed from the software by any user thereof.
 */

package com.seleritycorp.cs.standalone.commons.util.function;

import org.jetbrains.annotations.NotNull;

import java.util.Objects;

/**
 * Predicate operations as static methods since 1.8 "default" not available yet.
 */
public class PredicateOps {
    @NotNull
    public static <T> Predicate<T> and(@NotNull final Predicate<? super T> a, @NotNull final Predicate<? super T> b) {
        return new Predicate<T>() {
            @Override
            public boolean test(T t) {
                return a.test(t) && b.test(t);
            }
        };
    }

    @NotNull
    public static <T> Predicate<T> negate(@NotNull final Predicate<? super T> a) {
        return new Predicate<T>() {
            @Override
            public boolean test(T t) {
                return !a.test(t);
            }
        };
    }

    @NotNull
    public static <T> Predicate<T> or(@NotNull final Predicate<? super T> a, @NotNull final Predicate<? super T> b) {
        return new Predicate<T>() {
            @Override
            public boolean test(T t) {
                return a.test(t) || b.test(t);
            }
        };
    }

    @NotNull
    public static <T> Predicate<T> isEqual(final Object target) {
        return new Predicate<T>() {
            @Override
            public boolean test(T t) {
                return Objects.equals(target, t);
            }
        };
    }
}

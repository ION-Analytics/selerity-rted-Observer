/*
 * (c) Copyright Selerity, Inc. 2009-2013. All rights reserved. This source code is confidential
 * and proprietary information of Selerity Inc. and may be used only by a recipient designated
 * by and for the purposes permitted by Selerity Inc. in writing.  Reproduction of, dissemination
 * of, modifications to or creation of derivative works from this source code, whether in source
 * or binary forms, by any means and in any form or manner, is expressly prohibited, except with
 * the prior written permission of Selerity Inc..  THIS CODE AND INFORMATION ARE PROVIDED "AS IS"
 * WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. This notice may not be
 * removed from the software by any user thereof.
 */

package com.seleritycorp.cs.standalone.commons;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

/**
 * Date utilities.
 */
public class DateUtils {
    public static final String ISO_8601_PARSE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS";
    public static final String ISO_8601_FORMAT = ISO_8601_PARSE_FORMAT + "'000000'";
    public static final TimeZone UTC_TIMEZONE = TimeZone.getTimeZone("UTC");
    private static final ThreadLocal<SimpleDateFormat> ISO_8601_FORMATTER;
    private static final ThreadLocal<SimpleDateFormat> ISO_8601_PARSER;

    static {
        ISO_8601_FORMATTER = threadLocalSimpleDateFormat(ISO_8601_FORMAT);
        ISO_8601_FORMATTER.get().setTimeZone(UTC_TIMEZONE);

        ISO_8601_PARSER = threadLocalSimpleDateFormat(ISO_8601_PARSE_FORMAT);
        ISO_8601_PARSER.get().setTimeZone(UTC_TIMEZONE);
        ISO_8601_PARSER.get().setLenient(false);
    }

    /**
     * Java date to the ISO 8601 string format in UTC timezone.
     *
     * @param date the date to format
     * @return the formatted string
     */
    public static String format(Date date) {
        return ISO_8601_FORMATTER.get().format(date);
    }

    /**
     * Parse and ISO 8601 format string to a UNIX date.
     *
     * @param dateStr@return the Date
     * @return resultant date
     * @throws java.text.ParseException if it can not be passed
     */
    public static Date parse(String dateStr) throws ParseException {
        if (dateStr == null) {
            return null;
        }
        return ISO_8601_PARSER.get().parse(dateStr.substring(0, 23));
    }

    /**
     * A convenience method to return a thread local SimpleDateFormat.
     *
     * @param format the format
     * @return the thread local formatter
     */
    public static ThreadLocal<SimpleDateFormat> threadLocalSimpleDateFormat(final String format) {
        return new ThreadLocal<SimpleDateFormat>() {
            @Override
            protected SimpleDateFormat initialValue() {
                return new SimpleDateFormat(format);
            }
        };
    }
}

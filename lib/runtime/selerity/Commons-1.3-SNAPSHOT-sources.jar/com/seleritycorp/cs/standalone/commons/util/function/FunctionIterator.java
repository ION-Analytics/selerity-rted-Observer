/*
 * (c) Copyright Selerity, Inc. 2009-2013. All rights reserved. This source code is confidential
 * and proprietary information of Selerity Inc. and may be used only by a recipient designated
 * by and for the purposes permitted by Selerity Inc. in writing.  Reproduction of, dissemination
 * of, modifications to or creation of derivative works from this source code, whether in source
 * or binary forms, by any means and in any form or manner, is expressly prohibited, except with
 * the prior written permission of Selerity Inc..  THIS CODE AND INFORMATION ARE PROVIDED "AS IS"
 * WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. This notice may not be
 * removed from the software by any user thereof.
 */

package com.seleritycorp.cs.standalone.commons.util.function;

import org.jetbrains.annotations.NotNull;

import java.util.Iterator;

/**
 * An iterator produced by iteration applying a function.
 */
public class FunctionIterator<T, R> implements Iterator<R>, Iterable<R> {
    private final Iterator<T> iterator;
    private final Function<T, R> function;

    /**
     * Instantiate with the function and the underlying iterable.
     *
     * @param iterable Underlying iterable.
     * @param function Function to apply
     */
    public FunctionIterator(@NotNull Iterable<T> iterable, @NotNull Function<T, R> function) {
        this.iterator = iterable.iterator();
        this.function = function;
    }

    @Override
    public boolean hasNext() {
        return iterator.hasNext();
    }

    @Override
    public R next() {
        try {
            return function.apply(iterator.next());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void remove() {
        iterator.remove();
    }

    @Override
    public Iterator<R> iterator() {
        return this;
    }
}

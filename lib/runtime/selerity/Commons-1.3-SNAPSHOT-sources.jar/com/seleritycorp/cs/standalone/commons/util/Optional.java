/*
 * (c) Copyright Selerity, Inc. 2009-2013. All rights reserved. This source code is confidential
 * and proprietary information of Selerity Inc. and may be used only by a recipient designated
 * by and for the purposes permitted by Selerity Inc. in writing.  Reproduction of, dissemination
 * of, modifications to or creation of derivative works from this source code, whether in source
 * or binary forms, by any means and in any form or manner, is expressly prohibited, except with
 * the prior written permission of Selerity Inc..  THIS CODE AND INFORMATION ARE PROVIDED "AS IS"
 * WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. This notice may not be
 * removed from the software by any user thereof.
 */

package com.seleritycorp.cs.standalone.commons.util;

import org.jetbrains.annotations.NotNull;

import java.util.NoSuchElementException;

/**
 * An Optional implementation. Will be deprecated by 1.8
 */
public final class Optional<T> {
    private static final Optional EMPTY = new Optional<>();
    private final T optional;

    /**
     * Instantiate an Optional of a given non-null value.
     *
     * @param optional the value.
     */
    private Optional(@NotNull T optional) {
        if (optional == null) {
            throw new IllegalArgumentException("Optionals may not contain null value");
        }
        this.optional = optional;
    }

    /**
     * Instantiate an empty Optional.
     */
    private Optional() {
        optional = null;
    }

    @SuppressWarnings("unchecked")
    public static <T> Optional<T> empty() {
        return EMPTY;
    }

    @NotNull
    public static <T> Optional<T> of(T value) {
        return new Optional<>(value);
    }

    @NotNull
    public T get() throws NoSuchElementException {
        if (!isPresent()) {
            throw new NoSuchElementException("Attempting to get an empty Optional");
        }
        return optional;
    }

    public boolean isPresent() {
        return optional != null;
    }

    @NotNull
    public T orElse(T other) {
        if (isPresent()) {
            return get();
        }

        return other;
    }
}

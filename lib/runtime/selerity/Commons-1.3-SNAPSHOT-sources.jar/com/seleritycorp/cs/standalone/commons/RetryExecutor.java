/*
 * (c) Copyright Selerity, Inc. 2009-2013. All rights reserved. This source code is confidential
 * and proprietary information of Selerity Inc. and may be used only by a recipient designated
 * by and for the purposes permitted by Selerity Inc. in writing.  Reproduction of, dissemination
 * of, modifications to or creation of derivative works from this source code, whether in source
 * or binary forms, by any means and in any form or manner, is expressly prohibited, except with
 * the prior written permission of Selerity Inc..  THIS CODE AND INFORMATION ARE PROVIDED "AS IS"
 * WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. This notice may not be
 * removed from the software by any user thereof.
 */
package com.seleritycorp.cs.standalone.commons;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.selerityfinancial.util.time.Clock;


/**
 *  A facility for executing tasks such that if the task fails it will be automatically retried.
 */
public class RetryExecutor {
	private static final Log log = LogFactory.getLog(RetryExecutor.class);

	private final ExecutorService executorService;
	private final TimeQueue<TaskHolder> retryQueue = new TimeQueue<TaskHolder>();
	private final boolean failIsError;
	
	private final long initialDelayNanos;
	private final long delayMultiplier;
	private final int maxNumberOfRetries;
	
	/**
	 * Constructs a RetryExecutor which wraps the given ExecutorService and provides a mechanism for exponential back-off of repeated attempts of failed tasks.
	 * 
	 * @param executorService the service which will execute the tasks and the retries
	 * @param failIsError if true, failures are logged as errors, otherwise they're logged as warnings
	 * @param initialDelay the initial delay before retrying
	 * @param delayTimeUnit the time units of the initial delay
	 * @param delayMultiplier the multiplier of the delay for each subsequent retry
	 * @param maxNumberOfRetries the number of times that a failed task can be retried.  A value of zero means a task won't be retried at all if it fails on its first attempt.
	 */
	public RetryExecutor(final ExecutorService executorService, final boolean failIsError, final long initialDelay, final TimeUnit delayTimeUnit, final long delayMultiplier, final int maxNumberOfRetries) {
		this.executorService = executorService;
		this.failIsError = failIsError;
		this.initialDelayNanos = TimeUnit.NANOSECONDS.convert(initialDelay, delayTimeUnit);
		this.delayMultiplier = delayMultiplier;
		this.maxNumberOfRetries = maxNumberOfRetries;
		start();
	}

	/**
	 * Executes the given task.  If the task throws an exception then it will be retried according to the parameters passed in the constructor.
	 * 
	 * @param task a Runnable whose run() method will be executed.
	 * @param description a description of the task that will be included in the log if the task fails.
	 */
	public void execute(final Runnable task, final String description){
		Runnable wrapper = new Runnable(){
			public void run(){
				try{
					task.run();
					log.debug("task " + description + " succeeded");
				}
				catch (Exception ex){
					// log the failure
					if (failIsError){
						log.error("caught " + ex + " while running " + description, ex);
					}
					else{
						log.warn("caught " + ex + " while running " + description, ex);
					}
					
					if (maxNumberOfRetries >= 1){
						// now retry 
						final long nextTryTimeNanos = Clock.getTimeNanosStatic() + initialDelayNanos;
						log.info("will retry " + description + " at " + Clock.formatNanoTime(nextTryTimeNanos));
						TaskHolder taskHolder = new TaskHolder(task, description, nextTryTimeNanos, initialDelayNanos, 0);
						retryQueue.add(nextTryTimeNanos, taskHolder);
					}
					else{
						log.error("will not retry " + description);
					}
				}
			}
		};
		executorService.execute(wrapper);
	}
	
	private void retry(final TaskHolder taskHolder){
		Runnable wrapper = new Runnable(){
			public void run(){
				final int retries = taskHolder.getRetryCount() + 1;
				try{
					taskHolder.getTask().run();
					log.info("task " + taskHolder.getDescription() + " succeeded on after " + retries + " retries");
				}
				catch (Exception ex){
					// log the failure
					
					if (failIsError){
						log.error("caught " + ex + " while retrying " + taskHolder.getDescription() + "; this was retry #" + retries, ex);
					}
					else{
						log.warn("caught " + ex + " while retrying " + taskHolder.getDescription() + "; this was retry #" + retries, ex);
					}
					
					if (retries < maxNumberOfRetries){
						// retry again
						final long newDelayTimeNanos = taskHolder.getDelayTimeNanos() * delayMultiplier;
						final TaskHolder nextTaskHolder = new TaskHolder(taskHolder, newDelayTimeNanos);
						final long nextTryTimeNanos = nextTaskHolder.getNextTryTimeNanos();
						log.info("will retry " + nextTaskHolder.getDescription() + " at " + Clock.formatNanoTime(nextTryTimeNanos));
						retryQueue.add(nextTryTimeNanos, nextTaskHolder);
					}
					else{
						log.error("will not retry " + taskHolder.getDescription());
					}
				}
			}
		};
		executorService.execute(wrapper);
	}
	
	private void start(){
		Thread th = new Thread(new Runnable(){
			public void run(){
				while (true){
					final TaskHolder nextTask = retryQueue.waitForNextEntry();
					try{
						retry(nextTask);	
					}
					catch (Exception ex){
						log.error("caught " + ex + " while processing retry queue, ignoring", ex);
					}
					
				}
			}
		}, "retryQueueChecker");
		th.setDaemon(true);
		th.start();
		log.info("started thread to check the retry queue");
	}
	
	private final class TaskHolder{
		private final Runnable task;
		private final String description;
		private final long nextTryTimeNanos;
		private final long delayTimeNanos;
		private final int retryCount;
		
		public TaskHolder(final Runnable task, final String description, final long nextTryTimeNanos, final long delayTimeNanos, final int retryCount){
			this.task = task;
			this.description = description;
			this.nextTryTimeNanos = nextTryTimeNanos;
			this.delayTimeNanos = delayTimeNanos;
			this.retryCount = retryCount;
		}
		
		public TaskHolder(final TaskHolder previous, final long delayTimeNanos){
			this.task = previous.task;
			this.description = previous.description;
			this.nextTryTimeNanos = previous.nextTryTimeNanos + delayTimeNanos;
			this.delayTimeNanos = delayTimeNanos;
			this.retryCount = previous.retryCount + 1;
		}
		
		public Runnable getTask(){
			return task;
		}
		
		public String getDescription(){
			return description;
		}
		
		public long getNextTryTimeNanos(){
			return nextTryTimeNanos;
		}
		
		public long getDelayTimeNanos(){
			return delayTimeNanos;
		}
		
		public int getRetryCount(){
			return retryCount;
		}
		
		
	}
	
}

/*
 * (c) Copyright Selerity, Inc. 2009-2013. All rights reserved. This source code is confidential
 * and proprietary information of Selerity Inc. and may be used only by a recipient designated
 * by and for the purposes permitted by Selerity Inc. in writing.  Reproduction of, dissemination
 * of, modifications to or creation of derivative works from this source code, whether in source
 * or binary forms, by any means and in any form or manner, is expressly prohibited, except with
 * the prior written permission of Selerity Inc..  THIS CODE AND INFORMATION ARE PROVIDED "AS IS"
 * WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. This notice may not be
 * removed from the software by any user thereof.
 */

package com.seleritycorp.cs.standalone.commons.logging;

import org.apache.log4j.AppenderSkeleton;
import org.apache.log4j.spi.LoggingEvent;

import java.util.logging.Level;
import java.util.logging.Logger;

import static org.apache.log4j.Level.*;

/**
 * Can be used as a Log4j Appender to shunt messages to JUL.
 */
public class JULAppender extends AppenderSkeleton {

    @Override
    protected void append(LoggingEvent loggingEvent) {
        final Logger logger = Logger.getLogger(loggingEvent.getLoggerName());
        Level level = Level.INFO;

        switch (loggingEvent.getLevel().toInt()) {
            case ALL_INT:
                level = Level.ALL;
                break;
            case TRACE_INT:
                level = Level.FINER;
                break;
            case DEBUG_INT:
                level = Level.FINE;
                break;
            case INFO_INT:
                level = Level.INFO;
                break;
            case WARN_INT:
                level = Level.WARNING;
                break;
            case ERROR_INT:
                level = Level.SEVERE;
                break;
            case FATAL_INT:
                level = Level.SEVERE;
                break;
        }

        logger.logp(level,
                loggingEvent.getLocationInformation().getClassName(),
                loggingEvent.getLocationInformation().getMethodName(),
                loggingEvent.getRenderedMessage());
    }

    @Override
    public void close() {

    }

    @Override
    public boolean requiresLayout() {
        return false;
    }
}

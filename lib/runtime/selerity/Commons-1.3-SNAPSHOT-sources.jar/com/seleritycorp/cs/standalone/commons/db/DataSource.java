/*
 * (c) Copyright Selerity, Inc. 2009-2013. All rights reserved. This source code is confidential
 * and proprietary information of Selerity Inc. and may be used only by a recipient designated
 * by and for the purposes permitted by Selerity Inc. in writing.  Reproduction of, dissemination
 * of, modifications to or creation of derivative works from this source code, whether in source
 * or binary forms, by any means and in any form or manner, is expressly prohibited, except with
 * the prior written permission of Selerity Inc..  THIS CODE AND INFORMATION ARE PROVIDED "AS IS"
 * WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. This notice may not be
 * removed from the software by any user thereof.
 */

package com.seleritycorp.cs.standalone.commons.db;

import com.jolbox.bonecp.BoneCP;
import com.jolbox.bonecp.BoneCPConfig;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;


public class DataSource extends DataSourceAdapter {
    private final BoneCP connectionPool;

    public DataSource(DBConnectionInfo dbConnectionInfo) throws SQLException {
        super(dbConnectionInfo);
        final BoneCPConfig config = new BoneCPConfig();
        config.setJdbcUrl(dbConnectionInfo.getUrl());
        config.setUsername(dbConnectionInfo.getUser());
        config.setPassword(dbConnectionInfo.getPassword());
        config.setMaxConnectionsPerPartition(dbConnectionInfo.getMaxConnections() / 2 + 1);
        config.setPartitionCount(2);

        connectionPool = new BoneCP(config);

        getLogger().info("Creating dataSource: " + this);

        try (Connection connection = getConnection()) {
            getLogger().info("Testing " + toString() + " yielded: " + connection.toString());
        } catch (SQLException e) {
            getLogger().log(Level.SEVERE, "Failed to correctly set up database connection: " + toString(), e);
            throw e;
        }
    }

    @Override
    public Connection getConnection() throws SQLException {
        return connectionPool.getConnection();
    }

    @Override
    public Connection getConnection(String username, String password) throws SQLException {
        throw new UnsupportedOperationException("Method not implemented");
    }

    @Override
    public void close() throws Exception {
        connectionPool.close();
    }

}

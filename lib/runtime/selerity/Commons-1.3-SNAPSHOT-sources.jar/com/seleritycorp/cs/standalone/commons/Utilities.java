/*
 * (c) Copyright Selerity, Inc. 2009-2013. All rights reserved. This source code is confidential
 * and proprietary information of Selerity Inc. and may be used only by a recipient designated
 * by and for the purposes permitted by Selerity Inc. in writing.  Reproduction of, dissemination
 * of, modifications to or creation of derivative works from this source code, whether in source
 * or binary forms, by any means and in any form or manner, is expressly prohibited, except with
 * the prior written permission of Selerity Inc..  THIS CODE AND INFORMATION ARE PROVIDED "AS IS"
 * WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. This notice may not be
 * removed from the software by any user thereof.
 */

package com.seleritycorp.cs.standalone.commons;


import com.seleritycorp.cs.standalone.commons.util.function.Consumer;
import com.seleritycorp.cs.standalone.commons.util.function.Function;
import com.seleritycorp.cs.standalone.commons.util.function.FunctionIterator;
import com.seleritycorp.cs.standalone.commons.util.function.IterableOps;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.logging.Logger;

import static com.seleritycorp.cs.standalone.commons.util.function.IterableOps.forEach;
import static java.util.Arrays.asList;

public final class Utilities {
    private static final String NEWLINE = System.getProperty("line.separator");
    private static final Logger LOGGER = Logger.getLogger(Utilities.class.getName());
    private static final String HORIZONTAL_BAR = "===================================================================================================================";
    private static final Function<String, URL> STRING_TO_URL = new Function<String, URL>() {
        @NotNull
        @Override
        public URL apply(String from) {
            try {
                return new URL(from);
            } catch (MalformedURLException e) {
                throw new RuntimeException(e);
            }
        }
    };


    private Utilities() {
    }

    /**
     * Writes a banner to the console.
     *
     * @param caller class calling this method
     * @param title  banner title to print to the console
     */
    public static void consoleBanner(@NotNull final Object caller, final String title) {
        consoleBanner(caller.getClass().getSimpleName() + " : " + title);
    }

    /**
     * Writes a banner to the console.
     *
     * @param title banner title to print to the console
     */
    public static void consoleBanner(@NotNull final String title) {
        try {
            banner(title, System.out);
        } catch (IOException e) {
            LOGGER.warning("Failed writing banner: " + e);
        }
    }

    public static void banner(@NotNull final String msg, @NotNull OutputStream outputStream) throws IOException {
        StringBuilder stringBuilder = new StringBuilder(1024);

        stringBuilder.append(NEWLINE).append(NEWLINE).append(NEWLINE).append(NEWLINE);
        stringBuilder.append(HORIZONTAL_BAR).append(NEWLINE);
        stringBuilder.append(spacePad(msg)).append(NEWLINE);
        stringBuilder.append(HORIZONTAL_BAR).append(NEWLINE);
        outputStream.write(stringBuilder.toString().getBytes());
    }

    @NotNull
    public static String spacePad(@NotNull String s) {
        String result = "";
        for (char c : s.toCharArray()) {
            result += c + " ";
        }
        return result.toUpperCase();
    }

    /**
     * Gets the stack trace for an exception as a string.
     *
     * @param t exception
     * @return dump of the stack trace of the exception
     */
    @NotNull
    public static String getStackTrace(@NotNull Throwable t) {
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        t.printStackTrace(pw);
        return sw.getBuffer().toString();
    }

    /**
     * Gets string representation of an object, if object is null, result is null value.
     *
     * @param o object to convert
     * @return string representation of the object
     */
    @Nullable
    public static String toString(@Nullable Object o) {
        if (o == null) {
            return null;
        }
        return o.toString();
    }

    /**
     * Generate a java.util.UUID based on a "locality uuid".
     *
     * @return UUID
     * @see <a href="https://github.com/groupon/locality-uuid.java>Locality UUID</a>
     */
    @NotNull
    public static UUID generateUUID() {
        return UUID.fromString(new com.groupon.uuid.UUID().toString());
    }

    /**
     * Converts an object to UUID, if string is null or empty, returns null.
     *
     * @param o Object to convert
     * @return UUID from this object.
     */
    @Nullable
    public static UUID toUUID(@Nullable Object o) {
        try {
            if (o == null) {
                return null;
            } else if (o instanceof UUID) {
                return (UUID) o;
            } else {
                final String str = o.toString().trim();
                if (str == null || str.length() < 1 || str.equals("null")) {
                    return null;
                }
                return UUID.fromString(str);
            }
        } catch (Exception e) {
            throw new IllegalArgumentException("Problem converting '" + o + "' to UUID", e);
        }
    }


    /**
     * Assumes the string is substrings separated by a separator, returns the first substring.
     *
     * @param str       the string
     * @param separator the character separator
     * @return the first portion up to the separator
     */
    @Nullable
    public static String car(@Nullable String str, char separator) {
        if (str == null || str.indexOf(separator) < 0) {
            return str;
        }
        return str.substring(0, str.indexOf(separator));
    }

    /**
     * Assumes the string is substrings separated by a separator character, returns the last substring.
     *
     * @param str       the string
     * @param separator the separator
     * @return the final substring
     */
    @Nullable
    public static String cdr(@Nullable String str, char separator) {
        if (str == null || str.lastIndexOf(separator) < 0) {
            return str;
        }
        return str.substring(str.lastIndexOf(separator) + 1, str.length());
    }

    public static boolean notEmpty(@Nullable final String s) {
        return s != null && !isEmpty(s);
    }

    /**
     * Is this string, non null, but empty, ie comprise of zero or more whitespace characters.
     *
     * @param s the string
     * @return true if empty
     */
    public static boolean isEmpty(@Nullable final String s) {
        if (s == null) {
            throw new IllegalArgumentException("String argument cannot be null");
        }
        if (s.length() == 0) {
            return true;
        }

        return s.trim().length() == 0;
    }

    /**
     * Accepts a separator and a series of objects, returns a string built from the toString() of the objects
     * separated by the separator.
     *
     * @param separator A string to insert between objects
     * @param objects   objects to be appended
     * @return the resultant string
     */
    public static String append(String separator, Object... objects) {
        return Utilities.join(new ArrayIterator<>(objects), separator);
    }

    /**
     * Create a string join that uses a function to extract a string from members of an iterable.
     *
     * @param function  The function to apply
     * @param iterable  The thing to iterate
     * @param separator The string to separate the elements with
     * @param <T>       the type of the elements in the iteration
     * @return The string of the values returned by the function separated by the separator.
     */
    public static <T> String join(@NotNull Function<T, String> function, @NotNull Iterable<T> iterable, @NotNull String separator) {
        return Utilities.join(new FunctionIterator<>(iterable, function), separator);
    }

    /**
     * Joins an iteration of objects toString() representation separating them with a separator.
     *
     * @param iterable  The iterable
     * @param separator The separator
     * @param <T>       The type of the elements in the iteration
     * @return the joined string
     */
    public static <T> String join(final Iterable<T> iterable, final String separator) {
        final StringBuilder stringBuilder = new StringBuilder();

        forEach(iterable, new Consumer<T>() {
            @Override
            public void accept(T t) {
                if (stringBuilder.length() > 0) {
                    stringBuilder.append(separator);
                }
                stringBuilder.append(Utilities.toString(t));
            }
        });

        return stringBuilder.toString();
    }

    /**
     * Silently attempts to close an auto closeable resource.
     *
     * @param autoCloseable some resource
     */
    public static void close(@Nullable AutoCloseable autoCloseable) {
        if (autoCloseable == null) {
            return;
        }

        try {
            autoCloseable.close();
        } catch (Exception e) {
            LOGGER.info("Failed to close resource " + autoCloseable.getClass().getName() + ": " + e);
        }
    }

    @Nullable
    public static List<URL> toUrls(@Nullable String... urls) throws MalformedURLException {
        if (urls == null) {
            return new ArrayList<>();
        }

        try {
            return IterableOps.map(asList(urls), STRING_TO_URL);
        } catch (Exception e) {
            throw new MalformedURLException(e.toString());
        }
    }
}

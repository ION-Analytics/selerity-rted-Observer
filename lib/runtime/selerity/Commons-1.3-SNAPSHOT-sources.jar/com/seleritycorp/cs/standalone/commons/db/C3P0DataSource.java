/*
 * (c) Copyright Selerity, Inc. 2009-2013. All rights reserved. This source code is confidential
 * and proprietary information of Selerity Inc. and may be used only by a recipient designated
 * by and for the purposes permitted by Selerity Inc. in writing.  Reproduction of, dissemination
 * of, modifications to or creation of derivative works from this source code, whether in source
 * or binary forms, by any means and in any form or manner, is expressly prohibited, except with
 * the prior written permission of Selerity Inc..  THIS CODE AND INFORMATION ARE PROVIDED "AS IS"
 * WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. This notice may not be
 * removed from the software by any user thereof.
 */

package com.seleritycorp.cs.standalone.commons.db;


import com.mchange.v2.c3p0.ComboPooledDataSource;

import java.beans.PropertyVetoException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;

/**
 * A C3P0 pooling connection implementation.
 */
public class C3P0DataSource extends DataSourceAdapter {
    private final ComboPooledDataSource comboPooledDataSource;

    public C3P0DataSource(DBConnectionInfo dbConnectionInfo) throws SQLException {
        super(dbConnectionInfo);
        comboPooledDataSource = new ComboPooledDataSource();
        try {
            comboPooledDataSource.setDriverClass(dbConnectionInfo.getDriverClassName());
            comboPooledDataSource.setJdbcUrl(dbConnectionInfo.getUrl());
            comboPooledDataSource.setUser(dbConnectionInfo.getUser());
            comboPooledDataSource.setPassword(dbConnectionInfo.getPassword());
            comboPooledDataSource.setMaxPoolSize(dbConnectionInfo.getMaxConnections());
            comboPooledDataSource.setMinPoolSize(dbConnectionInfo.getMaxConnections() / 2);
        } catch (PropertyVetoException e) {
            throw new SQLException("Configuration issue: " + e);
        }

        getLogger().info("Creating dataSource: " + this);

        try (Connection connection = getConnection()) {
            getLogger().info("Testing " + toString() + " yielded: " + connection.toString());
        } catch (SQLException e) {
            getLogger().log(Level.SEVERE, "Failed to correctly set up database connection: " + toString(), e);
            throw e;
        }
    }

    @Override
    public void close() throws Exception {
        comboPooledDataSource.close();
    }

    @Override
    public Connection getConnection() throws SQLException {
        return comboPooledDataSource.getConnection();
    }

    @Override
    public Connection getConnection(String username, String password) throws SQLException {
        return comboPooledDataSource.getConnection(username, password);
    }

}

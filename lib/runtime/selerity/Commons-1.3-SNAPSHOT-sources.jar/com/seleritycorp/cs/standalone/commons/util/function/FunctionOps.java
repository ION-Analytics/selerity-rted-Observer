/*
 * (c) Copyright Selerity, Inc. 2009-2013. All rights reserved. This source code is confidential
 * and proprietary information of Selerity Inc. and may be used only by a recipient designated
 * by and for the purposes permitted by Selerity Inc. in writing.  Reproduction of, dissemination
 * of, modifications to or creation of derivative works from this source code, whether in source
 * or binary forms, by any means and in any form or manner, is expressly prohibited, except with
 * the prior written permission of Selerity Inc..  THIS CODE AND INFORMATION ARE PROVIDED "AS IS"
 * WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. This notice may not be
 * removed from the software by any user thereof.
 */

package com.seleritycorp.cs.standalone.commons.util.function;

/**
 *
 */
public class FunctionOps {

	/**
	 * Pipeline one function into another.
	 *
	 * @param before
	 * @param after
	 * @param <T>
	 * @param <R>
	 * @param <V>
	 * @return
	 */
	public static <T, R, V> Function<T, V> andThen(final Function<T, R> before, final Function<? super R, ? extends V> after) {
		return new Function<T, V>() {
			@Override
			public V apply(T t) {
				R r = before.apply(t);
				return after.apply(r);
			}
		};
	}
}

/*
 * (c) Copyright Selerity, Inc. 2009-2013. All rights reserved. This source code is confidential
 * and proprietary information of Selerity Inc. and may be used only by a recipient designated
 * by and for the purposes permitted by Selerity Inc. in writing.  Reproduction of, dissemination
 * of, modifications to or creation of derivative works from this source code, whether in source
 * or binary forms, by any means and in any form or manner, is expressly prohibited, except with
 * the prior written permission of Selerity Inc..  THIS CODE AND INFORMATION ARE PROVIDED "AS IS"
 * WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. This notice may not be
 * removed from the software by any user thereof.
 */

package com.seleritycorp.cs.standalone.commons.logging;

import java.io.IOException;
import java.io.InputStream;
import java.util.logging.LogManager;

import static com.seleritycorp.cs.standalone.commons.IOUtilities.getResourceAsStream;

/**
 * A Java Logging config that uses the standard system property java.util.logging.config.file as
 * a resource name to search application jars for.  So for example:
 * <p/>
 * java -Djava.util.logging.config.file=log.properties \
 * -Djava.util.logging.config.class=com.seleritycorp.cs.standalone.commons.logging.LoggingConfig \
 * -jar junit.jar
 * <p/>
 * Will search for log.properties in junit.jar and use those to configure Java logging.
 */
public class LoggingConfig {
    public LoggingConfig() {
        final String resource = System.getProperty("java.util.logging.config.file", "logging.properties");
        final InputStream inputStream = getResourceAsStream(resource);
        try {
            LogManager.getLogManager().readConfiguration(inputStream);
        } catch (IOException e) {
            System.err.println("Could not load logging config from resource " + resource);
        }
    }
}

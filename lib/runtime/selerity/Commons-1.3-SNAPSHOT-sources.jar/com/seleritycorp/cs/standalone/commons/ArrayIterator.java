/*
 * (c) Copyright Selerity, Inc. 2009-2013. All rights reserved. This source code is confidential
 * and proprietary information of Selerity Inc. and may be used only by a recipient designated
 * by and for the purposes permitted by Selerity Inc. in writing.  Reproduction of, dissemination
 * of, modifications to or creation of derivative works from this source code, whether in source
 * or binary forms, by any means and in any form or manner, is expressly prohibited, except with
 * the prior written permission of Selerity Inc..  THIS CODE AND INFORMATION ARE PROVIDED "AS IS"
 * WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. This notice may not be
 * removed from the software by any user thereof.
 */

package com.seleritycorp.cs.standalone.commons;

import java.util.Iterator;

/**
 * An iterator that operates over an array.
 */
public class ArrayIterator<T> implements Iterator<T>, Iterable<T> {
    private final T[] array;
    private int index = 0;

    public ArrayIterator(T[] array) {
        this.array = array;
    }

    @Override
    synchronized public boolean hasNext() {
        return array != null && array.length > index;
    }

    @Override
    synchronized public T next() {
        return array[index++];
    }

    @Override
    public void remove() {
        throw new UnsupportedOperationException("Method not implemented");
    }

    @Override
    public Iterator<T> iterator() {
        return this;
    }
}

/*
 * (c) Copyright Selerity, Inc. 2009-2013. All rights reserved. This source code is confidential
 * and proprietary information of Selerity Inc. and may be used only by a recipient designated
 * by and for the purposes permitted by Selerity Inc. in writing.  Reproduction of, dissemination
 * of, modifications to or creation of derivative works from this source code, whether in source
 * or binary forms, by any means and in any form or manner, is expressly prohibited, except with
 * the prior written permission of Selerity Inc..  THIS CODE AND INFORMATION ARE PROVIDED "AS IS"
 * WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. This notice may not be
 * removed from the software by any user thereof.
 */

package com.seleritycorp.cs.standalone.commons;

import java.net.MalformedURLException;
import java.net.URL;
import java.security.SignatureException;
import java.util.concurrent.TimeUnit;

import static com.seleritycorp.cs.standalone.commons.CryptoUtilities.calculateRFC2104HMAC;

/**
 * AWS Utilities
 */
public class AWSUtilities {
    private static final String AWS = "http://s3.amazonaws.com";

    /**
     * Create a URL with signature allowing protected s3 objects to be accessed.
     *
     * @param url          The s3 objects bucket and path, starts with leading /.
     * @param secretKey    s3 user secret key
     * @param accessKey    s3 users access key
     * @param validForUnit time unit to measure the expiration of this URL
     * @param validFor     the duration this url is valid for
     * @return resultant URL
     * @throws SignatureException
     * @throws MalformedURLException
     */
    public static URL awsUrl(final String url, final String secretKey, final String accessKey, final TimeUnit validForUnit, final long validFor) throws SignatureException, MalformedURLException {
        final long expires = TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis()) + validForUnit.toSeconds(validFor);
        final String signatureClearText = String.format("GET\n\n\n%d\n%s", expires, url);
        final String signature = calculateRFC2104HMAC(signatureClearText, secretKey);
        final String urlString = String.format("%s%s?AWSAccessKeyId=%s&Expires=%d&Signature=%s",
                AWS, url, accessKey, expires, signature);
        return new URL(urlString);
    }

    /**
     * Create a URL to access an unprotected S3 Object.
     *
     * @param s3Bucket S3 Bucket
     * @param s3Key S3 Key
     * @return Resultant URL
     * @throws MalformedURLException
     */
    public static URL url(final String s3Bucket, final String s3Key) throws MalformedURLException {
        return new URL(AWS + "/" + s3Bucket + "/" + s3Key);
    }
}

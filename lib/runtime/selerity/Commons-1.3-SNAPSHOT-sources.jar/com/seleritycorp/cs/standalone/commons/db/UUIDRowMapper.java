/*
 * (c) Copyright Selerity, Inc. 2009-2013. All rights reserved. This source code is confidential
 * and proprietary information of Selerity Inc. and may be used only by a recipient designated
 * by and for the purposes permitted by Selerity Inc. in writing.  Reproduction of, dissemination
 * of, modifications to or creation of derivative works from this source code, whether in source
 * or binary forms, by any means and in any form or manner, is expressly prohibited, except with
 * the prior written permission of Selerity Inc..  THIS CODE AND INFORMATION ARE PROVIDED "AS IS"
 * WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. This notice may not be
 * removed from the software by any user thereof.
 */

package com.seleritycorp.cs.standalone.commons.db;

import com.seleritycorp.cs.standalone.commons.logging.DoesLoggingImpl;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.UUID;

import static com.seleritycorp.cs.standalone.commons.Utilities.toUUID;

/**
 * Extracts a UUID from a result set column.
 */
public class UUIDRowMapper extends DoesLoggingImpl implements ParameterizedRowMapper<UUID> {

    private final String columnName;

    /**
     * Constructor, requires the name of the field that will contain the uuid
     *
     * @param columnName the column to extract
     */
    public UUIDRowMapper(String columnName) {
        this.columnName = columnName;
    }

    @Override
    public UUID mapRow(ResultSet resultSet, int i) throws SQLException {
        String idString = null;
        try {
            idString = resultSet.getString(columnName);
            if (idString == null || idString.trim().length() == 0) {
                return null;
            }
            return toUUID(idString);
        } catch (SQLException e) {
            getLogger().info("SQL Exception extracting uuid from " + columnName + " at row " + i + ": " + e);
            throw e;
        } catch (Exception e) {
            getLogger().info("SQL Exception extracting uuid from " + columnName + " at row " + i + ": " + e);
            throw new SQLException("Problem with id '" + idString + "' at row " + i, e);
        }
    }
}

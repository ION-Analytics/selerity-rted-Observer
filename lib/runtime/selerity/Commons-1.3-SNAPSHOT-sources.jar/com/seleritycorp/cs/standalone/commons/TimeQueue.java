/*
 * (c) Copyright Selerity, Inc. 2009-2013. All rights reserved. This source code is confidential
 * and proprietary information of Selerity Inc. and may be used only by a recipient designated
 * by and for the purposes permitted by Selerity Inc. in writing.  Reproduction of, dissemination
 * of, modifications to or creation of derivative works from this source code, whether in source
 * or binary forms, by any means and in any form or manner, is expressly prohibited, except with
 * the prior written permission of Selerity Inc..  THIS CODE AND INFORMATION ARE PROVIDED "AS IS"
 * WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. This notice may not be
 * removed from the software by any user thereof.
 */
package com.seleritycorp.cs.standalone.commons;

import java.util.ArrayList;
import java.util.List;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.concurrent.TimeUnit;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.selerityfinancial.util.time.Clock;

/**
 *  A structure which holds elements in a queue until their delivery time
 */
public class TimeQueue<E> {
	private static final Log log = LogFactory.getLog(TimeQueue.class);

	public class TimeQueueEntry implements Comparable<TimeQueueEntry>{
		private long timeNanos;
		private E entry;

		public TimeQueueEntry(final long time, final TimeUnit timeUnit, final E entry){
			this.timeNanos = TimeUnit.NANOSECONDS.convert(time, timeUnit);
			this.entry = entry;
		}

		public TimeQueueEntry(final Timestamp timestamp, final E entry){
			this.timeNanos = timestamp.getTimeInNanos();
			this.entry = entry;
		}

		public long getTimeNanos(){
			return timeNanos;
		}

		public long getTime(final TimeUnit timeUnit){
			return timeUnit.convert(timeNanos, TimeUnit.NANOSECONDS);
		}

		public E getEntry(){
			return entry;
		}

		/**
		 * @see java.lang.Comparable#compareTo(java.lang.Object)
		 */
		@Override
		public int compareTo(TimeQueueEntry other) {
			final long otherTimeNanos = other.timeNanos;
			if (otherTimeNanos > timeNanos){
				return 1;
			}
			else if (otherTimeNanos < timeNanos){
				return -1;
			}
			else{
				return 0;
			}
		}

		/**
		 * @see java.lang.Object#toString()
		 */
		@Override
		public String toString(){
			final String elementStr = entry == null ? "null" : entry.toString();
			return elementStr + " @ " + Clock.formatNanoTime(timeNanos);
		}

	}

	/**
	 * The sorted queue - maps timestamps to lists of entries
	 */
	private SortedMap<Long,List<E>> queue = new TreeMap<Long,List<E>>();

	/**
	 *  Constructs an empty TimeQueue instance.
	 */
	public TimeQueue() {
	}


	/**
	 * Returns true if the queue is empty, false otherwise.
	 * 
	 * @return true if the queue is empty, false otherwise.
	 */
	public synchronized boolean isEmpty(){
		return queue.isEmpty();
	}
	
	/**
	 * Adds an entry scheduled to be available at the given timestamp
	 * 
	 * @param timestamp the timestamp when the entry should become available
	 * @param entry the entry
	 */
	public void add(final Timestamp timestamp, final E entry){
		add(timestamp.getTimeInNanos(), entry);
	}

	/**
	 * Adds an entry scheduled to be available at the given time in nanoseconds since epoch.
	 * 
	 * @param timeNanos the time in nanoseconds since epoch
	 * @param entry
	 */
	public synchronized void add(final long timeNanos, final E entry){
		log.debug("adding entry " + entry + " scheduled at time " + Clock.formatNanoTime(timeNanos));
		List<E> entries = queue.get(timeNanos);
		if (entries == null){
			entries = new ArrayList<E>(1);
			queue.put(timeNanos, entries);
		}
		entries.add(entry);
		notifyAll();
	}

	/**
	 * Returns the first element in the queue which is before or at the given timestamp
	 * 
	 * @param timestamp the timestamp 
	 * @return the first entry in the queue (if one is available at or before this timestamp) or null
	 */
	public E getFirstEntryOnOrBefore(final Timestamp timestamp){
		return getFirstEntryOnOrBefore(timestamp.getTimeInNanos());
	}
	
	/**
	 * Returns the first element in the queue which is before or at the given time (in nanoseconds since epoch)
	 * 
	 * @param timeNanos the time in nanoseconds since epoch
	 * @return the first entry in the queue (if one is available at or before this time) or null
	 */
	public synchronized E getFirstEntryOnOrBefore(final long timeNanos){
		if (queue.isEmpty()){
			// there are no elements
			return null;
		}
		final Long firstKey = queue.firstKey();
		if (firstKey <= timeNanos){
			// there are some elements at or before this time
			final List<E> entries = queue.get(firstKey);
			final E entry = entries.remove(0);
			if (entries.isEmpty()){
				queue.remove(firstKey);
			}
			return entry;
		}
		// there are elements but they're after this time
		return null; 
	}

	/**
	 * Waits until the scheduled time for the first element in the queue is equal or greater than the current clock time.  May wait forever if no elements
	 * are placed into the queue.
	 * 
	 * @return the first entry in the queue
	 */
	public synchronized E waitForNextEntry(){
		while (true){
			final E entry = getFirstEntryOnOrBefore(Clock.getTimeNanosStatic());
			if (entry != null){
				log.debug("found an entry in the queue, returning it: " + entry);
				return entry;
			}
			// otherwise nothing was there (empty queue or not yet time) so we need to wait until that changes
			if (queue.isEmpty()){
				// no elements in the queue, sleep indefinitely
				try{
					log.debug("no elements in queue, waiting indefinitely");
					wait();
				}
				catch (InterruptedException ix){
					// ignore the interruption
				}
			}
			else{
				// wait until the next item in the queue (if not sooner)
				Long nextTime = queue.firstKey();
				// compute the time to wait
				try{
					final long totalWaitNanos = nextTime - Clock.getTimeNanosStatic();
					final long timeoutMillis = totalWaitNanos / Clock.NANOS_PER_MILLISECOND;
					final int remainingNanos = (int)(totalWaitNanos - (timeoutMillis * Clock.NANOS_PER_MILLISECOND));
					log.debug("waiting " + timeoutMillis + " ms + " + remainingNanos + " ns for the next entry in the queue (or sooner)");
					wait(timeoutMillis, remainingNanos);
				}
				catch (InterruptedException ix){
					// ignore the interruption
				}
			}
		}
	}


}

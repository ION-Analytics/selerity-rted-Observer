/*
 * (c) Copyright Selerity, Inc. 2009-2013. All rights reserved. This source code is confidential
 * and proprietary information of Selerity Inc. and may be used only by a recipient designated
 * by and for the purposes permitted by Selerity Inc. in writing.  Reproduction of, dissemination
 * of, modifications to or creation of derivative works from this source code, whether in source
 * or binary forms, by any means and in any form or manner, is expressly prohibited, except with
 * the prior written permission of Selerity Inc..  THIS CODE AND INFORMATION ARE PROVIDED "AS IS"
 * WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. This notice may not be
 * removed from the software by any user thereof.
 */

package com.seleritycorp.cs.standalone.commons.db;

import com.seleritycorp.cs.standalone.commons.logging.DoesLoggingImpl;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.SQLFeatureNotSupportedException;
import java.util.logging.Logger;

/**
 * A simple adapter that allows various 3rd party DataSource implementations be treated uniformly.
 */
public abstract class DataSourceAdapter extends DoesLoggingImpl implements javax.sql.DataSource, AutoCloseable {
    private PrintWriter logWriter = null;
    private final DBConnectionInfo dbConnectionInfo;

    public DataSourceAdapter(DBConnectionInfo dbConnectionInfo) throws SQLException {
        this.dbConnectionInfo = dbConnectionInfo;
        try {
            Class.forName(dbConnectionInfo.getDriverClassName());
        } catch (Exception e) {
            throw new SQLException("Could not load driver " + dbConnectionInfo.getDriverClassName());
        }
    }

    @Override
    public abstract Connection getConnection() throws SQLException;

    @Override
    public abstract Connection getConnection(String username, String password) throws SQLException;

    @Override
    public abstract void close() throws Exception;

    @Override
    public PrintWriter getLogWriter() throws SQLException {
        return logWriter;
    }

    @Override
    public void setLogWriter(PrintWriter out) throws SQLException {
        logWriter = out;
    }

    @Override
    public void setLoginTimeout(int seconds) throws SQLException {
        throw new UnsupportedOperationException("Method not implemented");
    }

    @Override
    public int getLoginTimeout() throws SQLException {
        throw new UnsupportedOperationException("Method not implemented");
    }

    @Override
    public Logger getParentLogger() throws SQLFeatureNotSupportedException {
        return getLogger().getParent();
    }

    @Override
    public <T> T unwrap(Class<T> iface) throws SQLException {
        throw new UnsupportedOperationException("Method not implemented");
    }

    @Override
    public boolean isWrapperFor(Class<?> iface) throws SQLException {
        throw new UnsupportedOperationException("Method not implemented");
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append("{dbConnectionInfo=").append(dbConnectionInfo);
        sb.append('}');
        return sb.toString();
    }
}

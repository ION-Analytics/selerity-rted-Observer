/*
 * (c) Copyright Selerity, Inc. 2009-2013. All rights reserved. This source code is confidential
 * and proprietary information of Selerity Inc. and may be used only by a recipient designated
 * by and for the purposes permitted by Selerity Inc. in writing.  Reproduction of, dissemination
 * of, modifications to or creation of derivative works from this source code, whether in source
 * or binary forms, by any means and in any form or manner, is expressly prohibited, except with
 * the prior written permission of Selerity Inc..  THIS CODE AND INFORMATION ARE PROVIDED "AS IS"
 * WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. This notice may not be
 * removed from the software by any user thereof.
 */

package com.seleritycorp.cs.standalone.commons;

import java.io.IOException;
import java.io.OutputStream;

/**
 * Produce Markdown formatted output.
 */
public final class Markdown {
    public static final String NEWLINE = System.getProperty("line.separator");
    private static final String[] HEADERS = {"######",
            "=====================================================================",
            "---------------------------------------------------------------------"};
    private static final String HR = HEADERS[2];
    private static final String BULLET = "\n*";
    private static final String INDENT = "    ";
    private static final String CODE = "`";
    private static final String ITALICS = "_";
    private static final String BOLD = "__";


    private Markdown() {
    }

    @Deprecated
    public static void header1(final String txt, OutputStream outputStream) throws IOException {
        header(txt, 1, outputStream);
    }

    @Deprecated
    public static void header2(final String txt, OutputStream outputStream) throws IOException {
        header(txt, 2, outputStream);
    }

    public static void code(final String txt, OutputStream outputStream) throws IOException {
        markdown(txt, CODE, outputStream);
    }

    public static void bold(final String txt, OutputStream outputStream) throws IOException {
        markdown(txt, BOLD, outputStream);
    }

    public static void italics(final String txt, OutputStream outputStream) throws IOException {
        markdown(txt, ITALICS, outputStream);
    }

    public static void bullet(OutputStream outputStream) throws IOException {
        outputStream.write(BULLET.getBytes());
    }

    public static void indent(OutputStream outputStream) throws IOException {
        outputStream.write(INDENT.getBytes());
    }

    public static void hr(OutputStream outputStream) throws IOException {
        markdown(HR, NEWLINE, outputStream);
    }

    public static void header(final String txt, int depth, OutputStream outputStream) throws IOException {
        depth = depth < 1 ? 1 : depth;
        depth = depth > 6 ? 6 : depth;

        switch (depth) {
            case 1:
            case 2:
                outputStream.write(txt.getBytes());
                outputStream.write(NEWLINE.getBytes());
                outputStream.write(HEADERS[depth].substring(0, txt.length()).getBytes());
                outputStream.write(NEWLINE.getBytes());
                break;
            default:
                outputStream.write(HEADERS[0].substring(0, depth).getBytes());
                outputStream.write(" ".getBytes());
                outputStream.write(txt.getBytes());
                outputStream.write(NEWLINE.getBytes());
                break;
        }


    }

    private static void markdown(final String txt, final String markdown, OutputStream outputStream) throws IOException {
        outputStream.write(markdown.getBytes());
        outputStream.write(txt.getBytes());
        outputStream.write(markdown.getBytes());
    }
}

/*
 * (c) Copyright Selerity, Inc. 2009-2013. All rights reserved. This source code is confidential
 * and proprietary information of Selerity Inc. and may be used only by a recipient designated
 * by and for the purposes permitted by Selerity Inc. in writing.  Reproduction of, dissemination
 * of, modifications to or creation of derivative works from this source code, whether in source
 * or binary forms, by any means and in any form or manner, is expressly prohibited, except with
 * the prior written permission of Selerity Inc..  THIS CODE AND INFORMATION ARE PROVIDED "AS IS"
 * WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. This notice may not be
 * removed from the software by any user thereof.
 */

package com.seleritycorp.cs.standalone.commons;

import com.seleritycorp.cs.standalone.commons.logging.DoesLoggingImpl;

import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;

/**
 * A class with a periodic task associated that will retry.
 */
public abstract class PeriodicTask extends DoesLoggingImpl implements ScheduledRunnable {
    private static final long MAX_RETRIES = 10L;
    private final Timer timer;
    private final TimeUnit unit;
    private final long initialDelay;
    private final long period;
    private final long delay;
    private final PeriodicTaskCaller periodicTaskCaller;

    protected PeriodicTask(TimeUnit unit, long period) {
        this(unit, period, period / MAX_RETRIES);
    }

    protected PeriodicTask(TimeUnit unit, long period, long initialDelay) {
        this.unit = unit;
        this.initialDelay = initialDelay;
        this.period = period;
        this.periodicTaskCaller = new PeriodicTaskCaller();

        timer = new Timer(this.getClass().getSimpleName(), true);
        timer.schedule(periodicTaskCaller, getUnit().toMillis(getInitialDelay()), getUnit().toMillis(getPeriod()));
        delay = Math.min(initialDelay, getPeriod() / MAX_RETRIES);
        getLogger().info("Periodic task running: " + toString());
    }

    protected abstract void periodicTask() throws Exception;

    public Timer getTimer() {
        return timer;
    }

    @Override
    public long getInitialDelay() {
        return initialDelay;
    }

    @Override
    public long getPeriod() {
        return period;
    }

    @Override
    public TimeUnit getUnit() {
        return unit;
    }

    @Override
    public Runnable getRunnable() {
        return periodicTaskCaller;
    }

    /**
     * Task to reload tickers.
     */
    private class PeriodicTaskCaller extends TimerTask {

        @Override
        public void run() {
            int retries = 0;

            while (retries < MAX_RETRIES) {
                try {
                    if (retries > 0) {
                        getUnit().sleep(delay);
                    }
                    getLogger().info("running periodicTask");
                    periodicTask();
                    break;
                } catch (Exception e) {
                    retries++;
                    getLogger().log(Level.WARNING, "Task failed. Retry " + retries + " will be attempted in " + delay + " " + unit, e);
                }
            }
        }
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("PeriodicTask{");
        sb.append("unit=").append(unit);
        sb.append(", period=").append(period);
        sb.append(", initialDelay=").append(initialDelay);
        sb.append(", delay=").append(delay);
        sb.append('}');
        return sb.toString();
    }
}

/*
 * (c) Copyright Selerity, Inc. 2009-2013. All rights reserved. This source code is confidential
 * and proprietary information of Selerity Inc. and may be used only by a recipient designated
 * by and for the purposes permitted by Selerity Inc. in writing.  Reproduction of, dissemination
 * of, modifications to or creation of derivative works from this source code, whether in source
 * or binary forms, by any means and in any form or manner, is expressly prohibited, except with
 * the prior written permission of Selerity Inc..  THIS CODE AND INFORMATION ARE PROVIDED "AS IS"
 * WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. This notice may not be
 * removed from the software by any user thereof.
 */

package com.seleritycorp.cs.standalone.commons.caching;

import com.seleritycorp.cs.standalone.commons.logging.DoesLoggingImpl;
import org.jetbrains.annotations.NotNull;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

/**
 * This class will encapsulates a map and adds simple caching features.  In particular it will:
 * <p/>
 * <ul>
 * <li>Allows a size limit to be set</li>
 * <li>Uses a least recently used policy to evict entries</li>
 * <li>Allows for an expiration time to be set on entries</li>
 * <li>Can lazy load entries on cache miss</li>
 * </ul>
 * <p/>
 * Synchronization of instances depends on two factors, the Map used and the concurrency level set. If you
 * encapsulate a non synchronized map, or you set it's concurrency level below 2 the instance will not be synchronized.
 * <p/>
 * The caching features make this about 150% slower then a HashMap when not synchronized and 350% slower when synchronized.
 * Those numbers still make it faster then Google's Guava or Ehcache.
 */
public class SimpleCache<K, V> extends DoesLoggingImpl implements Map<K, V>, Lookup<K, V>, AbstractCacheMBean.ManageableCache {
    private static final int DEFAULT_CONCURRENCY = 4;
    private static final int DEFAULT_SIZE = 1_000;
    private final Map<K, V> map;
    private final Lookup<K, V> cacheValueLookup;
    private final Map<K, Future<V>> lookingFor = new HashMap<>();
    private final Comparator<Entry<K, Long>> refComparator = new Comparator<Entry<K, Long>>() {
        @Override
        public int compare(Entry<K, Long> o1, Entry<K, Long> o2) {
            return o1.getValue().compareTo(o2.getValue());
        }
    };
    private int maximumSize = DEFAULT_SIZE;
    private final Map<K, Long> references;
    private TimeUnit timeToLiveUnits = null;
    private long timeToLive = 0;
    private int hitCount = 0;
    private int missCount = 0;

    /**
     * Instantiate a synchronized instance.
     */
    public SimpleCache() {
        this(null, null, DEFAULT_CONCURRENCY);
    }

    public SimpleCache(int size, Lookup<K, V> cacheValueLookup) {
        this(null, cacheValueLookup, DEFAULT_CONCURRENCY);
        setMaximumSize(size);
    }

    /**
     * Instantiate an instance at a designated concurrency level.
     *
     * @param concurrencyLevel Number of threads anticipated. Less then 2 will cause this to not be synchronized.
     */
    public SimpleCache(int concurrencyLevel) {
        this(null, null, concurrencyLevel);
    }

    /**
     * Instantiate an instance using an existing map.
     *
     * @param map the map to wrap this cache around.
     */
    public SimpleCache(Map<K, V> map) {
        this(map, null, DEFAULT_CONCURRENCY);
    }

    public SimpleCache(Map<K, V> map, Lookup<K, V> cacheValueLookup) {
        this(map, cacheValueLookup, DEFAULT_CONCURRENCY);
    }

    public SimpleCache(Map<K, V> map, Lookup<K, V> cacheValueLookup, int concurrencyLevel) {
        this.map = map != null ? map : concurrencyLevel > 1 ?
                new ConcurrentHashMap<K, V>(maximumSize, 1.0f, concurrencyLevel) :
                new HashMap<K, V>(maximumSize);
        this.cacheValueLookup = cacheValueLookup;
        references = concurrencyLevel > 1 ? new ConcurrentHashMap<K, Long>(maximumSize, 1.0f, concurrencyLevel) : new HashMap<K, Long>(maximumSize);
    }

    @Override
    public int size() {
        return map.size();
    }

    @Override
    public boolean isEmpty() {
        return map.isEmpty();
    }

    @Override
    public boolean containsKey(Object key) {
        return map.containsKey(key);
    }

    @Override
    public boolean containsValue(Object value) {
        return map.containsValue(value);
    }

    @SuppressWarnings("unchecked")
    @Override
    public V get(Object key) {
        V value = map.get(key);

        if (value != null && expired((K) key)) {
            remove(key);
            value = null;
        }

        if (value != null) {
            ++hitCount;
        } else {
            ++missCount;
            if (cacheValueLookup != null) {
                // We have a cache lookup functor
                Future<V> lookupFuture;
                synchronized (lookingFor) {
                    // See if we are looking for this item already?
                    lookupFuture = lookingFor.get(key);
                    if (lookupFuture != null) {
                        --missCount;
                    } else {
                        // nope - create new future lookup for it
                        lookupFuture = new LookupFuture<>(cacheValueLookup, (K) key);
                        lookingFor.put((K) key, lookupFuture);
                    }
                }
                assert lookupFuture != null;
                try {
                    value = lookupFuture.get();
                } catch (InterruptedException | ExecutionException e) {
                    getLogger().info("Cache lookup throw exception: " + e);
                }
                if (value != null) {
                    put((K) key, value);
                }
                synchronized (lookingFor) {
                    lookingFor.remove(key);
                }
            }
        }

        if (value != null) {
            references.put((K) key, System.currentTimeMillis());
        }

        return value;
    }

    @Override
    public V put(K key, V value) {
        int space = getMaximumSize() - size();
        while (space <= 0) {
            remove(oldest());
            ++space;
        }
        references.put(key, System.currentTimeMillis());
        return map.put(key, value);
    }

    @Override
    public V remove(Object key) {
        references.remove(key);
        return map.remove(key);
    }

    @Override
    public void putAll(@NotNull Map<? extends K, ? extends V> m) {
        map.putAll(m);
    }

    @Override
    public void clear() {
        references.clear();
        map.clear();
        hitCount = missCount = 0;
    }

    @Override
    @NotNull
    public Set<K> keySet() {
        return map.keySet();
    }

    @Override
    @NotNull
    public Collection<V> values() {
        return map.values();
    }

    @Override
    @NotNull
    public Set<Entry<K, V>> entrySet() {
        return map.entrySet();
    }

    @Override
    public int getMaximumSize() {
        return maximumSize;
    }

    @Override
    public void setMaximumSize(int maximumSize) {
        this.maximumSize = maximumSize;
    }

    public Map<K, V> getMap() {
        return map;
    }

    @Override
    public TimeUnit getTimeToLiveUnits() {
        return timeToLiveUnits;
    }

    @Override
    public void setTimeToLiveUnits(TimeUnit timeToLiveUnits) {
        this.timeToLiveUnits = timeToLiveUnits;
    }

    @Override
    public long getTimeToLive() {
        return timeToLive;
    }

    @Override
    public void setTimeToLive(long timeToLive) {
        this.timeToLive = timeToLive;
    }

    @Override
    public int getCacheHitCount() {
        return hitCount;
    }

    @Override
    public int getCacheMissCount() {
        return missCount;
    }

    /**
     * Private methods
     */

    private K oldest() {
        try {
            return Collections.min(references.entrySet(), refComparator).getKey();
        } catch (Exception e) {
            return null;
        }
    }

    private boolean expired(K key) {
        if (timeToLive == 0 || timeToLiveUnits == null) {
            return false;
        }

        Long inserted = references.get(key);
        if (inserted == null) {
            return false;
        }

        return System.currentTimeMillis() - inserted > timeToLiveUnits.toMillis(timeToLive);
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("SimpleCache{");
        sb.append("cacheValueLookup=").append(cacheValueLookup != null);
        sb.append(", maximumSize=").append(maximumSize);
        sb.append(", timeToLiveUnits=").append(timeToLiveUnits);
        sb.append(", timeToLive=").append(timeToLive);
        sb.append(", hitCount=").append(hitCount);
        sb.append(", missCount=").append(missCount);
        sb.append('}');
        return sb.toString();
    }
}

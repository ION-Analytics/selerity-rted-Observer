/*
 * (c) Copyright Selerity, Inc. 2009-2012. All rights reserved. This source code is confidential 
 * and proprietary information of Selerity Inc. and may be used only by a recipient designated 
 * by and for the purposes permitted by Selerity Inc. in writing.  Reproduction of, dissemination 
 * of, modifications to or creation of derivative works from this source code, whether in source 
 * or binary forms, by any means and in any form or manner, is expressly prohibited, except with 
 * the prior written permission of Selerity Inc..  THIS CODE AND INFORMATION ARE PROVIDED "AS IS"
 * WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. This notice may not be 
 * removed from the software by any user thereof.
 */

package com.seleritycorp.cs.standalone.commons;

import org.junit.Test;

import java.util.Map;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertNotNull;
import static junit.framework.Assert.assertNull;

public class LruCacheTest {
    @Test
    public void testFifoCache() throws Exception {
        final int max = 4;
        Map<Integer, Integer> fifoCache = new LruCache<>(max);

        // test the simple scenario where it should push an item off end
        for (int x = 0 ; x <= max; x++ ) {
            fifoCache.put(x,x);
        }
        
        assertEquals(max, fifoCache.size());
        assertNotNull(fifoCache.get(max));
        assertNull(fifoCache.get(0));
    }

    @Test
    public void testReallyLru() throws Exception {
        final int max = 4;
        Map<Integer, Integer> fifoCache = new LruCache<>(max);

        // test the simple scenario where it should push an item off end
        for (int x = 0 ; x < max; x++ ) {
            fifoCache.put(x,x);
        }

        assertEquals(max, fifoCache.size());
        assertNotNull(fifoCache.get(0));
        assertNotNull(fifoCache.get(max-1));

        /*
         Made it here, the cache is loaded and we've accessed position 0. If this is LRU and we add one more
         0 should not be ejected, 1 should be.
        */

        fifoCache.put(100,100);
        assertNotNull(fifoCache.get(0));
        assertNull(fifoCache.get(1));
    }
}

/*
 * © Copyrights Selerity, Inc. 2009-2011. All rights reserved. This source code is confidential
 * and proprietary information of Selerity Inc. and may be used only by a recipient designated
 * by and for the purposes permitted by Selerity Inc. in writing.  Reproduction of, dissemination
 * of, modifications to or creation of derivative works from this source code, whether in source
 * or binary forms, by any means and in any form or manner, is expressly prohibited, except with
 * the prior written permission of Selerity Inc..  THIS CODE AND INFORMATION ARE PROVIDED "AS IS"
 * WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. This notice may not be
 * removed from the software by any user thereof.
 */

package com.seleritycorp.cs.standalone.commons;

import net.sf.ehcache.CacheManager;
import net.sf.ehcache.config.CacheConfiguration;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.Random;

import static org.junit.Assert.*;

public class TypeSafeCacheTest {

    private TypeSafeCache<Integer, Timestamp> instance;
    private static final CacheManager CACHE_MANAGER = CacheManager.create();
    private static final String CACHE_NAME = "temp.cache";
    private static final Random rand = new Random();

    @Before
    public void setUp() throws Exception {
        instance = new TypeSafeCache<Integer, Timestamp>(new CacheConfiguration(CACHE_NAME, 1000));
        CACHE_MANAGER.addCache(instance);
    }

    @After
    public void tearDown() throws Exception {
        CACHE_MANAGER.removalAll();
    }

    @Test
    public void testGet() throws Exception {
        Utilities.consoleBanner(this, "get (null key)");
        assertNull(instance.get(null));
    }

    @Test
    public void testGet2() throws Exception {
        Utilities.consoleBanner(this, "get (not found)");
        assertNull(instance.get(99));
    }

    @Test
    public void testGet3() throws Exception {
        Utilities.consoleBanner(this, "get (OK)");
        Integer number = rand.nextInt();
        Timestamp added = new Timestamp();
        instance.put(number, added);
        Timestamp found = instance.getObject(number);
        assertNotNull(found);
        assertEquals(added.getTimeInNanos(), found.getTimeInNanos());
    }

    @Test
    public void testGet4() throws Exception {
        Utilities.consoleBanner(this, "get (OK)");
        Integer number = rand.nextInt();
        Timestamp added = new Timestamp();
        instance.put(number, added);
        Timestamp found1 = instance.getObject(number);
        Timestamp found2 = instance.getObject(number);
        assertNotNull(found1);
        assertNotNull(found2);
        assertEquals(found2.getTimeInNanos(), found1.getTimeInNanos());
    }

    @Test
    public void testPut() throws Exception {
        Utilities.consoleBanner(this, "put (OK)");
        Integer number = rand.nextInt();
        Timestamp added = new Timestamp();
        instance.put(number, added);
        Timestamp found = instance.getObject(number);
        assertNotNull(found);
        assertEquals(added.getTimeInNanos(), found.getTimeInNanos());
    }
}

/*
 * (c) Copyrights Selerity, Inc. 2009-2011. All rights reserved. This source code is confidential
 * and proprietary information of Selerity Inc. and may be used only by a recipient designated
 * by and for the purposes permitted by Selerity Inc. in writing.  Reproduction of, dissemination
 * of, modifications to or creation of derivative works from this source code, whether in source
 * or binary forms, by any means and in any form or manner, is expressly prohibited, except with
 * the prior written permission of Selerity Inc..  THIS CODE AND INFORMATION ARE PROVIDED “AS IS”
 * WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. This notice may not be
 * removed from the software by any user thereof.
 */

package com.seleritycorp.cs.standalone.commons;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.config.CacheConfiguration;
import net.sf.ehcache.constructs.blocking.CacheEntryFactory;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static com.seleritycorp.cs.standalone.commons.Utilities.consoleBanner;
import static org.junit.Assert.*;

public class CacheMapDecoratorTest {

    private CacheMapDecorator<String, String> instance;
    private static final CacheManager CACHE_MANAGER = CacheManager.create();
    private static final String CACHE_NAME = "temp.cache2";

    @Before
    public void setUp() throws Exception {
        Cache cache = new Cache(new CacheConfiguration(CACHE_NAME, 10));
        CACHE_MANAGER.addCache(cache);
        instance = new CacheMapDecorator<String, String>(cache);
    }

    @After
    public void tearDown() throws Exception {
        CACHE_MANAGER.removalAll();
    }

    @Test
    public void testSanity() throws Exception {
        consoleBanner(this,"sanity");
        instance.put("a","b");
        assertEquals("b", instance.get("a"));
        assertNull(instance.get("c"));
    }

    @Test
    public void testSelfPopulating() {
        consoleBanner(this, "Self Populating");
        CacheMapDecorator<String, String> map = new CacheMapDecorator<String, String>(new CacheConfiguration(CACHE_NAME, 10), new Retriever());

        assertNotNull(map);
        assertEquals("AAA", map.get("aaa"));
    }

    private class Retriever implements CacheEntryFactory {
        @Override
        public Object createEntry(Object o) throws Exception {
            return ((String)o).toUpperCase();
        }
    }
}

/*
 * (c) Copyrights Selerity, Inc. 2009-2011. All rights reserved. This source code is confidential
 * and proprietary information of Selerity Inc. and may be used only by a recipient designated
 * by and for the purposes permitted by Selerity Inc. in writing.  Reproduction of, dissemination
 * of, modifications to or creation of derivative works from this source code, whether in source
 * or binary forms, by any means and in any form or manner, is expressly prohibited, except with
 * the prior written permission of Selerity Inc..  THIS CODE AND INFORMATION ARE PROVIDED “AS IS”
 * WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. This notice may not be
 * removed from the software by any user thereof.
 */

package com.seleritycorp.cs.standalone.commons;

import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Ehcache;
import net.sf.ehcache.Element;
import net.sf.ehcache.config.CacheConfiguration;
import net.sf.ehcache.constructs.blocking.CacheEntryFactory;
import net.sf.ehcache.constructs.blocking.SelfPopulatingCache;

import java.util.Collection;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

/**
 *   A cache decorator to make it into a more type safe Map.
 */
public class CacheMapDecorator<K, V> implements Map<K, V>, Lookup<K, V> {
    private final Ehcache cache;

    /**
     * Instantiates an instance that decorates a SelfPopulatingCache.
     * @param configuration the cache configuration
     * @param retriever the retriever
     */
    public CacheMapDecorator(CacheConfiguration configuration, CacheEntryFactory retriever) {
        CacheManager cacheManager = CacheManager.create();

        net.sf.ehcache.Cache underlyingCache = cacheManager.getCache(configuration.getName());
        if (underlyingCache == null) {
            underlyingCache = new net.sf.ehcache.Cache(configuration);
            cacheManager.addCache(underlyingCache);
        }
        this.cache = new SelfPopulatingCache(underlyingCache, retriever);
    }

    /**
     * Instantiate a CacheMapDecorator as a decorator of provided cache.
     * @param cache the cache to decorate.
     */
    public CacheMapDecorator(Ehcache cache) {
        this.cache = cache;
    }

    /**
     * Gets a cached value for a given key.
     *
     * @param key key
     * @return cached value
     */
    @SuppressWarnings("unchecked")
    @Override
    public V get(Object key) {
        if (key == null) {
            return null;
        }
        Element elem;
        if ((elem = cache.get(key)) != null) {
            return (V) elem.getObjectValue();
        }
        return null;
    }

    /**
     * Puts a value into the cache.
     *
     * @param key   key
     * @param value value
     */
    @Override
    public V put(K key, V value) {
        if (key != null && value != null) {
            V prev = get(key);
            cache.put(new Element(key, value));
            return prev;
        }
        return null;
    }

    @Override
    public int size() {
        return cache.getSize();
    }

    @Override
    public boolean isEmpty() {
        return cache.getSize() == 0;
    }

    @Override
    public boolean containsKey(Object o) {
        return cache.isKeyInCache(o);
    }

    @Override
    public boolean containsValue(Object o) {
        return cache.isValueInCache(o);
    }

    @Override
    public V remove(Object o) {
        V prev = get(o);
        cache.remove(o);
        return prev;
    }

    @Override
    public void putAll(Map<? extends K, ? extends V> map) {
        for (K key : map.keySet()) {
            put(key, map.get(key));
        }
    }

    @Override
    public void clear() {
        cache.removeAll();
    }

    @Override
    @SuppressWarnings("unchecked")
    public Set<K> keySet() {
        return new TreeSet<K>(cache.getKeys());
    }

    @Override
    public Collection<V> values() {
        throw new UnsupportedOperationException("Method not implemented");
    }

    @Override
    public Set<Entry<K, V>> entrySet() {
        throw new UnsupportedOperationException("Method not implemented");
    }

    /**
     * Get the underlying cache.
     * @return the cache
     */
    public Ehcache getCache() {
        return cache;
    }
}

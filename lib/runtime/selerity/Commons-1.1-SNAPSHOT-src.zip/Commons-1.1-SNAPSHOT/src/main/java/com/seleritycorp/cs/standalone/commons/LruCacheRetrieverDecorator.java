/*
 * (c) Copyright Selerity, Inc. 2009-2012. All rights reserved. This source code is confidential
 * and proprietary information of Selerity Inc. and may be used only by a recipient designated
 * by and for the purposes permitted by Selerity Inc. in writing.  Reproduction of, dissemination
 * of, modifications to or creation of derivative works from this source code, whether in source
 * or binary forms, by any means and in any form or manner, is expressly prohibited, except with
 * the prior written permission of Selerity Inc..  THIS CODE AND INFORMATION ARE PROVIDED "AS IS"
 * WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. This notice may not be
 * removed from the software by any user thereof.
 */

package com.seleritycorp.cs.standalone.commons;

import net.sf.ehcache.constructs.blocking.CacheEntryFactory;

import java.util.logging.Logger;

/**
 * A decorator to lookup on miss.
 */
public class LruCacheRetrieverDecorator<K, V> extends LruCache<K,V> {
    private final Logger logger = Logger.getLogger(getClass().getName());
    private final CacheEntryFactory retriever;
    private long cacheHitCount = 0;
    private long cacheMissCount = 0;

    public LruCacheRetrieverDecorator(int maxElementsInMemory, CacheEntryFactory retriever) {
        super(maxElementsInMemory);
        if (retriever == null) {
            throw new IllegalArgumentException("Retriever must not be null.");
        }
        this.retriever = retriever;
    }

    public long getCacheHitCount() {
        return cacheHitCount;
    }

    public long getCacheMissCount() {
        return cacheMissCount;
    }

    @SuppressWarnings("unchecked")
    @Override
    public V get(Object o) {
        V found = super.get(o);
        if (found != null) {
            cacheHitCount++;
            return found;
        }
        cacheMissCount++;
        try {
            found = (V) retriever.createEntry(o);
            if (found != null) {
                put((K)o, found);
            }
            return found;
        } catch (Exception e) {
            logger.info("Cache lookup failure: " + e);
        }
        return null;
    }
}

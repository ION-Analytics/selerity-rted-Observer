/*
 * (c) Copyrights Selerity, Inc. 2009-2011. All rights reserved. This source code is confidential
 * and proprietary information of Selerity Inc. and may be used only by a recipient designated
 * by and for the purposes permitted by Selerity Inc. in writing.  Reproduction of, dissemination
 * of, modifications to or creation of derivative works from this source code, whether in source
 * or binary forms, by any means and in any form or manner, is expressly prohibited, except with
 * the prior written permission of Selerity Inc..  THIS CODE AND INFORMATION ARE PROVIDED “AS IS”
 * WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. This notice may not be
 * removed from the software by any user thereof.
 */

package com.seleritycorp.cs.standalone.commons;

import net.sf.ehcache.Ehcache;
import net.sf.ehcache.statistics.LiveCacheStatistics;
import org.springframework.jmx.export.annotation.ManagedAttribute;
import org.springframework.jmx.export.annotation.ManagedOperation;

/**
 * Abstract super class for MBeans that report on cache health.
 */
public abstract class AbstractCacheMBean {

    /**
     * Return the TaskingCache that is managed.
     * @return the tasking cache
     */
    protected abstract Ehcache getCache();

    /**
     * Gets number of cache hits.
     * @return the number of hits
     */
    @ManagedAttribute(description = "Gets number of cache hits.")
    public long getHits() {
        return getLiveCacheStatstics().getCacheHitCount();
    }

    /**
     * Get the number of cache misses.
     * @return the number of misses
     */
    @ManagedAttribute(description = "Gets number of cache misses.")
    public long getMisses() {
        return getLiveCacheStatstics().getCacheMissCount();
    }

    /**
     * Get the percentage of cache hits.
     * @return percentage of cache hits
     */
    @ManagedAttribute(description = "Gets percentage of cache hits.")
    public double getPercentHits() {
        double hits = getHits();
        double misses = getMisses();
        return 100.0 * hits / (hits + misses);
    }

    /**
     * The number of objects in the cache.
     * @return the object count
     */
    @ManagedAttribute(description = "Gets number of objects in the cache.")
    public long getObjectCount() {
        return getLiveCacheStatstics().getSize();
    }

    /**
     * The number of memory store objects in the cache.
     * @return the object count
     */
    @ManagedAttribute(description = "Gets number of memory store objects in the cache.")
    public long getMemoryStoreObjectCount() {
        return getLiveCacheStatstics().getInMemorySize();
    }

    /**
     * The number of disk-store objects in the cache.
     * @return the object count
     */
    @ManagedAttribute(description = "Gets number of disk store objects in the cache.")
    public long getDiskStoreObjectCount() {
        return getLiveCacheStatstics().getOnDiskSize();
    }

    /**
     * The number of heap store objects in the cache.
     * @return the object count
     */
    @ManagedAttribute(description = "Gets number of heap store objects in the cache.")
    public long getOffHeapStoreObjectCount() {
        return getLiveCacheStatstics().getOffHeapSize();
    }

    /**
     * Clear the statistics.
     */
    @ManagedOperation(description = "Clears statistics.")
    public void clearStatistics() {
        getLiveCacheStatstics().clearStatistics();
    }

    /**
     * Invalidate the cache.
     */
    @ManagedOperation(description = "Invalidates the cache.")
    public void invalidate() {
        getCache().removeAll();
    }

    /**
     * Gets the time to live in seconds of the objects stored in the cache
     * @return the time to live in seconds
     */
    @ManagedAttribute(description = "Gets the time to live in seconds of the objects stored in the cache.")
    public long getTimeToLiveSeconds() {
        return getCache().getCacheConfiguration().getTimeToLiveSeconds();
    }

    /**
     * Gets the number of max elements in memory
     * @return the number of max elements in memory
     */
    @ManagedAttribute(description = "Gets number of max elements in memory.")
    public int getMaxElementsInMemory() {
        return getCache().getCacheConfiguration().getMaxElementsInMemory();
    }

    /**
     * Sets the number of max elements in memory
     * @param maxElementsInMemory max elements in memory
     */
    @ManagedAttribute(description = "Sets number of max elements in memory.")
    public void setMaxElementsInMemory(int maxElementsInMemory) {
        getCache().getCacheConfiguration().setMaxElementsInMemory(maxElementsInMemory);
    }

    @ManagedAttribute(description = "Are statistics on?")
    public boolean isStatisticsEnabled() {
        return getCache().isStatisticsEnabled();
    }

    @ManagedAttribute(description = "Set statistics gathering.")
    public void setStatisticsEnabled(boolean value) {
        getCache().setStatisticsEnabled(value);
    }

    private LiveCacheStatistics getLiveCacheStatstics() {
        return getCache().getLiveCacheStatistics();
    }
}

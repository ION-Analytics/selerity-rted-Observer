/*
 * © Copyrights Selerity, Inc. 2009-2011. All rights reserved. This source code is confidential
 * and proprietary information of Selerity Inc. and may be used only by a recipient designated
 * by and for the purposes permitted by Selerity Inc. in writing.  Reproduction of, dissemination
 * of, modifications to or creation of derivative works from this source code, whether in source
 * or binary forms, by any means and in any form or manner, is expressly prohibited, except with
 * the prior written permission of Selerity Inc..  THIS CODE AND INFORMATION ARE PROVIDED "AS IS"
 * WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. This notice may not be
 * removed from the software by any user thereof.
 */

package com.seleritycorp.cs.standalone.commons;

import net.sf.ehcache.Cache;
import net.sf.ehcache.Element;
import net.sf.ehcache.config.CacheConfiguration;

import java.io.Serializable;

/**
 * @deprecated Create a cache and use the CacheMapDecorator
 * @param <K>
 * @param <V>
 */
@Deprecated
public class TypeSafeCache<K extends Serializable, V extends Serializable> extends Cache {

    public TypeSafeCache(final CacheConfiguration configuration) {
        super(configuration);
    }

    /**
     * Gets a cached value for a given key.
     *
     * @param key key
     * @return cached value
     */
    @SuppressWarnings("unchecked")
    public V getObject(K key) {
        if (key == null) {
            return null;
        }
        Element elem;
        if ((elem = super.get(key)) != null) {
            return (V) elem.getObjectValue();
        }
        return null;
    }

    /**
     * Puts a value into the cache.
     *
     * @param key   key
     * @param value value
     */
    public void put(K key, V value) {
        if (key != null && value != null) {
            put(new Element(key, value));
        }
    }

    public boolean containsKey(K key) {
        return get(key) != null;
    }
}

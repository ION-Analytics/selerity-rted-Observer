/*
 * (c) Copyright Selerity, Inc. 2009-2012. All rights reserved. This source code is confidential
 * and proprietary information of Selerity Inc. and may be used only by a recipient designated
 * by and for the purposes permitted by Selerity Inc. in writing.  Reproduction of, dissemination
 * of, modifications to or creation of derivative works from this source code, whether in source
 * or binary forms, by any means and in any form or manner, is expressly prohibited, except with
 * the prior written permission of Selerity Inc..  THIS CODE AND INFORMATION ARE PROVIDED "AS IS"
 * WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. This notice may not be
 * removed from the software by any user thereof.
 */

package com.seleritycorp.cs.standalone.commons;

import org.springframework.jmx.export.annotation.ManagedAttribute;
import org.springframework.jmx.export.annotation.ManagedOperation;

import java.util.Map;

/**
 * Abstract super class for MBeans that report on a map.
 */
public abstract class AbstractMapMBean<M extends Map> {

    protected abstract M getMap();

    /**
     * The number of objects in the map.
     * @return the object count
     */
    @ManagedAttribute(description = "Gets number of objects in the map.")
    public int getSize() {
        return getMap().size();
    }

    /**
     * cleap the map.
     */
    @ManagedOperation(description = "Invalidates the cache.")
    public void clear() {
        getMap().clear();
    }

}
